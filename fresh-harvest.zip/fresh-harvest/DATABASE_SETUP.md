# Fresh Harvest - Database Setup Instructions

## 🔧 Required Database Updates

After updating the application, you must run these SQL commands in your MySQL database.

### Step 1: Access phpMyAdmin

1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Login with your MySQL credentials (usually username: `root`, no password)
3. Select the database: **`fresh_harvest`**

### Step 2: Run SQL Commands

Click on the **"SQL"** tab and paste these commands:

```sql
-- Add password column to users table for registered user authentication
ALTER TABLE users ADD COLUMN IF NOT EXISTS password VARCHAR(255);

-- Add is_registered column to distinguish between registered and guest users
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_registered BOOLEAN DEFAULT FALSE;

-- Update existing users (optional - marks users with passwords as registered)
UPDATE users SET is_registered = TRUE WHERE password IS NOT NULL AND password != '';
```

### Step 3: Execute

Click the **"Go"** button or press **Enter** to execute the commands.

## ✅ Verification

After running the commands, verify the columns were added:

```sql
DESCRIBE users;
```

You should see:
- `password` column (VARCHAR 255)
- `is_registered` column (BOOLEAN)

## 📊 Current Database Schema

### Users Table Structure:
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(40),
    address TEXT,
    password VARCHAR(255),              -- NEW: For registered users
    is_registered BOOLEAN DEFAULT FALSE, -- NEW: User type indicator
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
```

## 🔐 User Types

The system now supports two types of users:

### 1. **Registered Users** (is_registered = TRUE)
- Have passwords (hashed)
- Can login to account
- Can view order history
- Information pre-filled in checkout
- Access: `http://localhost/fresh-harvest/user/login.php`

### 2. **Guest Users** (is_registered = FALSE)
- Created during checkout
- No password
- Can still place orders
- Information saved in database
- No login required

## 📝 Default Admin Credentials

**Admin Panel:** `http://localhost/fresh-harvest/admin/`

- **Username:** admin
- **Password:** admin123

⚠️ **Important:** Change these credentials in production!

## 🚀 Testing the Setup

1. Navigate to the login page: `http://localhost/fresh-harvest/user/login.php`
2. Click on **"Register"** tab
3. Create a new account with:
   - Full Name
   - Email
   - Password (min. 6 characters)
4. Login with your new credentials
5. Go to Shop and place an order

## ⚠️ Troubleshooting

### "Table 'fresh_harvest.users' doesn't exist"?
- Ensure you've imported the `fresh_harvest.sql` file first
- Run: `SOURCE database/fresh_harvest.sql;` in MySQL

### "SQL syntax error"?
- Make sure you're in the correct database (fresh_harvest)
- Copy commands exactly as shown
- Check for typos

### Columns already exist?
- That's OK! The `IF NOT EXISTS` clause prevents errors
- Commands will simply be skipped if columns are present

## 📲 Customer Features After Setup

✅ User registration and login
✅ Account password protection
✅ Secure session management
✅ Pre-filled checkout form for registered users
✅ Account status visible in admin dashboard
✅ Distinction between registered and guest customers

---

**Database Version:** 1.1
**Last Updated:** April 5, 2026

For issues, contact: admin@freshharvest.local
