# Fresh Harvest - Image Upload & Product Management Guide

## 📸 How to Upload Product Images

### Step 1: Access Admin Dashboard
1. Go to: `http://localhost/fresh-harvest/admin/`
2. Login with:
   - **Username:** admin
   - **Password:** admin123

### Step 2: Add Product with Image
1. Click **"Products"** in the sidebar
2. Fill in the product details:
   - **Product name:** Name of the product (e.g., "Fresh Apples")
   - **Category:** Select from dropdown (Fruits, Vegetables, Herbs, Organic)
   - **Price (₹):** Enter price in Indian Rupees (e.g., 150)
   - **Description:** Add product details
   - **Upload Image:** Click to browse and select an image file

### Step 3: Submit
1. Click **"Add Product"** button
2. The product image will be uploaded to the `uploads/` folder
3. Product will appear in the table below

## 🖼️ Image Requirements

- **Supported Formats:** JPG, JPEG, PNG, GIF, WebP
- **Recommended Size:** 500x500 pixels or larger
- **Max File Size:** Recommended under 2MB
- **Aspect Ratio:** Square images work best for product cards

## 📊 Where Products Appear

### For Customers:
1. **Home Page:** `http://localhost/fresh-harvest/`
   - Featured products section shows 6 latest products
   - Displays: Product image, name, description, and price

2. **Shop Page:** `http://localhost/fresh-harvest/user/menu.php`
   - All products displayed in grid
   - Shows: Image, name, category, description, price
   - "Add to Cart" button for each product

### For Admin:
1. **Products Table:** `http://localhost/fresh-harvest/admin/food.php`
   - Shows all products with ID, name, category, and price
   - Delete button to remove products

## 💰 Pricing in Rupees (₹)

Prices are now displayed in **Indian Rupees (₹)** across the entire application:

- **Admin Dashboard:** 
  - Product prices in admin panel show as ₹ symbol
  - Revenue statistics show as ₹
  
- **User Pages:**
  - Home page featured products: ₹
  - Shop page: ₹
  - Cart page: ₹
  - Checkout: ₹

## 📁 File Upload System

### Upload Directory Structure:
```
uploads/
├── {timestamp}_{filename}.jpg
├── {timestamp}_{filename}.png
└── README.txt
```

**Example:** `1680000000_fresh_apples.jpg`

### Features:
- Automatic timestamp prefix prevents filename conflicts
- Images accessible from product cards
- Fallback to logo if image is missing

## ⚙️ Technical Details

### Image Path Handling:
- Images stored in: `uploads/` directory
- Relative path stored in database: `uploads/filename.jpg`
- Accessed via: `../uploads/filename.jpg` (from user pages)

### Error Handling:
- If image doesn't load, fallback displays logo
- Missing images won't break product display
- Invalid file types rejected during upload

## 🔒 Security

- Only image file types allowed (.jpg, .jpeg, .png, .gif, .webp)
- Files stored outside web root for added security
- `.htaccess` file configured for image serving

## 🐛 Troubleshooting

### Image Not Showing?
1. Check if file was uploaded (check `uploads/` folder)
2. Verify correct file format (JPG, PNG, etc.)
3. Clear browser cache and refresh
4. Check file permissions on `uploads/` folder

### Upload Failed?
1. Ensure `uploads/` folder has write permissions
2. Check file size is under 2MB
3. Verify file format is supported
4. Check available disk space

### All Products Show Default Logo?
1. Check `uploads/` directory exists
2. Verify write permissions: `755` or `775`
3. Ensure image files are actually uploaded
4. Check `assets/images/logo.png` exists as fallback

## 📝 Notes

- Prices display in ₹ (rupees) throughout the system
- Each product upload is timestamped for uniqueness
- Categories can be managed from **Categories** section
- Products display in order (latest first on home, alphabetical in shop)

---

**For Support:** Contact admin@freshharvest.local
