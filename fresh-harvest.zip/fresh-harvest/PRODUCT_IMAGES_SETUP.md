# Product Images Setup Guide for Fresh Harvest

## Important: Add Product Images to `assets/images/` Folder

The website now includes 20 high-quality products in the database. To display them with images, you need to add the following image files to the `assets/images/` folder.

### Required Product Images (PNG format recommended)

Place these image files in: `assets/images/`

1. **red-apple.png** - Fresh Red Apples
2. **banana.png** - Golden Bananas
3. **orange.png** - Fresh Oranges
4. **strawberry.png** - Organic Strawberries
5. **mango.png** - Ripe Mangoes
6. **spinach.png** - Green Spinach
7. **tomato.png** - Cherry Tomatoes
8. **carrot.png** - Organic Carrots
9. **bell-pepper.png** - Bell Peppers Mix
10. **broccoli.png** - Fresh Broccoli
11. **basil.png** - Organic Basil
12. **mint.png** - Green Mint Leaves
13. **garlic.png** - Garlic Bulbs
14. **onion.png** - Onions Fresh
15. **potato.png** - Organic Potatoes
16. **cucumber.png** - Fresh Cucumbers
17. **peas.png** - Green Peas
18. **lettuce.png** - Organic Lettuce
19. **radish.png** - Radishes Bundle
20. **beet.png** - Beets Fresh

Also ensure you have:
- **placeholder.png** - Default image for products without images (500x500px)

## Image Specifications

### Recommended Settings:
- **Format:** PNG or JPG
- **Size:** 500x500 pixels (square format works best)
- **File Size:** 100-300 KB per image
- **Color Space:** RGB
- **Quality:** High quality, clear product images

### How to Get AI-Generated Images:

You can use these free AI image generation services:

1. **OpenAI DALL-E** (https://openai.com/dall-e-2)
   - Generate with prompts like: "high quality photo of fresh red apples on white background"

2. **Midjourney** (https://midjourney.com)
   - Professional quality AI images
   - Prompt: "professional product photography of fresh organic red apples, studio lighting, white background"

3. **Stable Diffusion** (https://stability.ai)
   - Free and open-source
   - Good for product images

4. **Leonardo.AI** (https://leonardo.ai)
   - Fast generation of product images
   - Good for e-commerce

5. **Canva** (https://canva.com)
   - Has AI image generation built-in
   - Also has stock photos

### Suggested Prompts for Each Product:

```
- Red Apples: "Professional photography of fresh red apples, studio lighting, white background"
- Bananas: "Golden yellow bunch of bananas, product photo, professional lighting"
- Oranges: "Fresh ripe oranges, studio photography, clean background"
- Strawberries: "Red organic strawberries, professional food photography, white background"
- Mango: "Ripe yellow mango, high quality product photo, studio lighting"
- Spinach: "Fresh green spinach leaves, organic produce, clean presentation"
- Tomatoes: "Cherry red tomatoes, farm fresh produce, professional photography"
- Carrots: "Orange organic carrots, product photography, bright lighting"
- Bell Peppers: "Colorful bell peppers red green yellow, studio photography"
- Broccoli: "Fresh green broccoli florets, organic produce photography"
- Basil: "Fresh green basil leaves, herbs, professional photo"
- Mint: "Green mint leaves, fresh herbs, product photography"
- Garlic: "Fresh garlic bulbs, white garlic cloves, professional photo"
- Onions: "Golden onions, farm fresh produce, studio lighting"
- Potatoes: "Brown organic potatoes, farm produce photography"
- Cucumbers: "Fresh green cucumbers, product photo, clean background"
- Green Peas: "Fresh green peas in pod, organic produce"
- Lettuce: "Fresh green lettuce leaves, salad greens, professional photo"
- Radishes: "Red radishes with greens, fresh produce, clean styling"
- Beets: "Red beets with soil, organic produce, product photography"
```

## Step-by-Step Setup:

1. **Generate or Find Images**
   - Use AI services listed above to generate product images
   - OR download from free stock photo sites like Unsplash, Pexels, Pixabay

2. **Name Files Correctly**
   - Match the filenames exactly as listed above (e.g., `red-apple.png`)
   - Use lowercase with hyphens, no spaces

3. **Place in Correct Folder**
   - Copy all images to: `fresh-harvest/assets/images/`
   - Ensure folder exists and is writable

4. **Test the Display**
   - Go to: `http://localhost/fresh-harvest/user/menu.php`
   - All 20 products should display with images
   - If image not found, placeholder will show

5. **Upload via Admin Panel**
   - Can also upload individual product images via admin dashboard
   - Images uploaded via admin go to `uploads/` folder
   - Default products use images from `assets/images/` folder

## File Structure

```
fresh-harvest/
├── assets/
│   ├── images/
│   │   ├── red-apple.png
│   │   ├── banana.png
│   │   ├── orange.png
│   │   ├── ... (all 20 product images)
│   │   ├── placeholder.png
│   │   └── logo.png
│   └── css/
│       └── style.css
├── uploads/
│   └── (user-uploaded product images)
└── ... (other folders)
```

## Troubleshooting

### Images Not Showing?

1. **Check File Names**
   - Verify filenames match exactly
   - Use lowercase with hyphens (red-apple.png, NOT Red_Apple.PNG)

2. **Check File Location**
   - Confirm images are in `assets/images/` folder
   - Not in `uploads/` or other folders

3. **Check File Permissions**
   - Ensure web server can read the files
   - File permissions should be 644 or 755

4. **Clear Browser Cache**
   - Refresh browser (Ctrl+F5 or Cmd+Shift+R)
   - Clear browser cache if still not showing

5. **Verify Image Format**
   - Supported: PNG, JPG, GIF, WebP
   - Ensure file has correct extension

## CSS Styling for Images

The website now features:
- **Bright Green Theme** (#2a8f66 primary color)
- **Modern Gradient Backgrounds**
- **Smooth Hover Effects**
- **Professional Typography**
- **Responsive Design**
- **Product Image Boxes** with rounded corners
- **Shadow Effects** for depth
- **Color Transitions** on interaction

## Testing Products Display

### Admin Panel:
- **Products Page:** `http://localhost/fresh-harvest/admin/food.php`
  - Shows product images in table
  - Can edit or delete products
  - New Edit button available

### User Pages:
- **Home Page:** `http://localhost/fresh-harvest/`
  - Featured products with images
  
- **Shop Page:** `http://localhost/fresh-harvest/user/menu.php`
  - All 20 products with images
  - Add to cart functionality
  
- **Cart & Checkout:** 
  - Shows selected products
  - All in-rupees pricing

## Additional Features

### Admin Edit Page:
- Click "Edit" button on any product
- Change name, category, price, description
- Upload new image for existing product
- Preview current product details

### Image Handling:
- Automatic fallback to placeholder if image missing
- Images from `assets/images/` and `uploads/` both supported
- Admin can use either folder for product images

---

**Next Steps:**
1. Generate or download 20 product images
2. Place in `assets/images/` folder with correct names
3. Refresh website to see products with images
4. Test all functionality!

For AI image generation, start with OpenAI DALL-E or Midjourney for best results.
