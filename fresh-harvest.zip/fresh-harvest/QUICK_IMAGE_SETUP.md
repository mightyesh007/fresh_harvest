# How to Create Placeholder and Product Images

## Quick Guide for Placeholder Image

Since you need placeholder images, here are the easiest options:

### Option 1: Quick Placeholder Generator (Recommended)

Use an online service to create a simple placeholder:

1. Go to: https://via.placeholder.com
2. Generate image: `https://via.placeholder.com/500x500?text=Product+Image`
3. Right-click → "Save Image As"
4. Save as: `assets/images/placeholder.png`

### Option 2: Color-Coded Placeholders

Create different color placeholders for different categories:

1. **Fruits:** https://via.placeholder.com/500x500/FF6B6B?text=Fruits
   - Save as: `assets/images/placeholder.png`

2. **Vegetables:** https://via.placeholder.com/500x500/4ECDC4?text=Vegetables
   - Save as: `assets/images/placeholder-veggie.png`

3. **Herbs:** https://via.placeholder.com/500x500/95E1D3?text=Herbs
   - Save as: `assets/images/placeholder-herb.png`

4. **Organic:** https://via.placeholder.com/500x500/38ADA9?text=Organic
   - Save as: `assets/images/placeholder-organic.png`

## Getting Product Images

### Free AI Image Services (Recommended):

#### 1. **DALL-E 3** (Best Quality)
- Website: https://openai.com/dall-e-3
- Free credits on signup
- Example: "professional product photo of red apple on white background, 8k"

#### 2. **Midjourney** (Professional)
- Website: https://midjourney.com
- First 25 images free
- Better for consistent styling

#### 3. **Stable Diffusion XL** (Fast & Free)
- Website: https://clipdrop.co/stable-diffusion
- No login required
- Example: "professional product photography of carrots, studio lighting"

#### 4. **Leonardo.AI** (E-Commerce Focused)
- Website: https://leonardo.ai
- Good for product images
- Free tier available

#### 5. **Free Stock Photo Sites**:
- **Unsplash:** https://unsplash.com (search "vegetables", "fruits", etc.)
- **Pexels:** https://pexels.com
- **Pixabay:** https://pixabay.com
- **Freepik:** https://freepik.com (free images available)

## Easy Setup Steps

### Step 1: Download/Create Images
1. Visit one of the AI sites above
2. Generate images using prompts from PRODUCT_IMAGES_SETUP.md
3. Download each image (usually right-click → save)

### Step 2: Rename Files
Rename according to this pattern:
- `red-apple.png` for Red Apples
- `banana.png` for Bananas
- `orange.png` for Oranges
- (See PRODUCT_IMAGES_SETUP.md for complete list)

### Step 3: Create Folder & Upload
1. Navigate to: `fresh-harvest/assets/images/`
2. Create folder if it doesn't exist
3. Upload all renamed images here

### Step 4: Test
1. Go to: `http://localhost/fresh-harvest/user/menu.php`
2. Refresh page
3. All products should show with images!

## Windows File Explorer Method

If you're not tech-savvy, here's the easiest way:

1. **Create Folder:**
   - Navigate to: `C:\xampp\htdocs\fresh-harvest\assets\`
   - Right-click → New → Folder
   - Name it: `images`

2. **Download Images:**
   - Go to https://via.placeholder.com
   - Download placeholder images
   - Save to newly created folder

3. **Add Product Images:**
   - Download from Unsplash/Pexels (easiest)
   - Rename files to match product names
   - Copy to `assets/images/` folder

4. **Verify:**
   - Open `http://localhost/fresh-harvest/user/menu.php`
   - Images should display

## Fastest Setup (10 minutes)

1. **Download Placeholder Bundle:**
   - Create one placeholder: `https://via.placeholder.com/500x500/2a8f66?text=Fresh+Harvest`
   - Save as: `assets/images/placeholder.png`

2. **Use For All Products:**
   - Don't upload individual product images yet
   - All products will show placeholder
   - Add real images later one by one

3. **Later Add Individual Images:**
   - Via Admin Panel → Products → Edit
   - Upload individual product images
   - They'll appear immediately

## If You Have Photoshop/GIMP

Create custom placeholders:
1. New document: 500x500px, RGB
2. Background color: your brand color (#2a8f66 or similar)
3. Add text: Product name
4. Export as PNG
5. Save to `assets/images/`

## Mobile/Phone Users

1. Use your phone to take actual photos of fruits/vegetables
2. Upload to phone → computer
3. Save to `assets/images/` folder with correct names
4. Works perfectly!

## Quick Prompts for AI Services

For DALL-E/Midjourney, use these prompts:

```
"Professional product photography of {product}, studio lighting, 
white background, 4K high quality, realistic, 
commercial photography style"

Examples:
"Professional product photography of fresh red apples, studio lighting, white background"
"Product photo of golden bananas, premium quality, white background"
"Professional photo of fresh green spinach, organic produce, clean background"
```

## Troubleshooting

### Images Not Showing?
1. Check file names (use lowercase with hyphens)
2. Verify folder location: `assets/images/`
3. Clear browser cache (Ctrl+Shift+Delete)
4. Refresh page (Ctrl+F5)

### Files Won't Upload?
1. Check folder permissions (should be 755)
2. Ensure web server has write access
3. Try uploading via Admin Panel instead

### Image Too Large?
1. Use an image compressor: https://tinypng.com
2. Reduce to 500x500 pixels
3. Then upload to folder

---

**Remember:**
- Filenames MUST match exactly (red-apple.png, NOT red-apple.jpg or redapple.png)
- All images should be in: `assets/images/` folder
- Size: 500x500 pixels recommended
- Format: PNG or JPG
- Free AI image services allow 25-50 free images per month!

Start with a placeholder (2 minutes), then add real images gradually!
