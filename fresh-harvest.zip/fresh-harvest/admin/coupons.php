<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$message = '';
$action = $_GET['action'] ?? '';

// Create coupon
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create') {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $discount_type = $_POST['discount_type'] ?? 'percentage';
    $discount_value = (float) ($_POST['discount_value'] ?? 0);
    $min_order = (float) ($_POST['min_order_amount'] ?? 0);
    $max_usage = $_POST['max_usage'] ? (int) $_POST['max_usage'] : null;
    $valid_from = $_POST['valid_from'] ?? date('Y-m-d');
    $valid_until = $_POST['valid_until'] ?? date('Y-m-d', strtotime('+30 days'));

    if ($code && $discount_value > 0) {
        try {
            $stmt = $pdo->prepare('INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, max_usage, valid_from, valid_until, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)');
            $stmt->execute([$code, $discount_type, $discount_value, $min_order, $max_usage, $valid_from, $valid_until]);
            $message = 'Coupon created successfully!';
        } catch (Exception $e) {
            $message = 'Error: ' . $e->getMessage();
        }
    } else {
        $message = 'Please fill in all required fields.';
    }
}

// Delete coupon
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $pdo->prepare('DELETE FROM coupons WHERE id = ?')->execute([$id]);
    header('Location: coupons.php');
    exit;
}

// Toggle coupon status
if ($action === 'toggle' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare('SELECT is_active FROM coupons WHERE id = ?');
    $stmt->execute([$id]);
    $coupon = $stmt->fetch();
    if ($coupon) {
        $pdo->prepare('UPDATE coupons SET is_active = ? WHERE id = ?')->execute([!$coupon['is_active'], $id]);
    }
    header('Location: coupons.php');
    exit;
}

// Get all coupons
$coupons = $pdo->query('SELECT * FROM coupons ORDER BY created_at DESC')->fetchAll();
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Discount Coupons</h2>

    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'Error') === false ? 'success' : 'error' ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Create New Coupon Form -->
    <div style="background: #f3f7f6; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
        <h3 style="margin-top: 0;">Create New Coupon</h3>
        <form method="post" action="?action=create" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Coupon Code</label>
                <input type="text" name="code" placeholder="e.g., WELCOME10" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Discount Type</label>
                <select name="discount_type" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="percentage">Percentage (%)</option>
                    <option value="flat">Flat (₹)</option>
                </select>
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Discount Value</label>
                <input type="number" name="discount_value" step="0.01" placeholder="e.g., 10" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Min Order Amount (₹)</label>
                <input type="number" name="min_order_amount" step="0.01" placeholder="0" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Max Usage (optional)</label>
                <input type="number" name="max_usage" placeholder="Leave empty for unlimited" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Valid From</label>
                <input type="date" name="valid_from" value="<?= date('Y-m-d') ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Valid Until</label>
                <input type="date" name="valid_until" value="<?= date('Y-m-d', strtotime('+30 days')) ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div style="display: flex; align-items: flex-end;">
                <button type="submit" style="background: #2a8f66; color: white; padding: 8px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">Create Coupon</button>
            </div>
        </form>
    </div>

    <!-- Coupons Table -->
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #f3f7f6;">
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Code</th>
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Type</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Value</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Min Amount</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Usage</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Valid Until</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Status</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($coupons as $coupon): ?>
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px;"><strong><?= htmlspecialchars($coupon['code']) ?></strong></td>
                <td style="padding: 12px;"><?= ucfirst($coupon['discount_type']) ?></td>
                <td style="padding: 12px; text-align: center;">
                    <?= $coupon['discount_value'] ?>
                    <?= $coupon['discount_type'] === 'percentage' ? '%' : '₹' ?>
                </td>
                <td style="padding: 12px; text-align: center;">₹<?= number_format($coupon['min_order_amount'], 2) ?></td>
                <td style="padding: 12px; text-align: center;">
                    <?= $coupon['usage_count'] ?>
                    <?php if ($coupon['max_usage']): ?>
                        / <?= $coupon['max_usage'] ?>
                    <?php else: ?>
                        / ∞
                    <?php endif; ?>
                </td>
                <td style="padding: 12px; text-align: center;"><?= date('M d, Y', strtotime($coupon['valid_until'])) ?></td>
                <td style="padding: 12px; text-align: center;">
                    <span style="<?= $coupon['is_active'] ? 'color: #4caf50;' : 'color: #f44336;' ?> font-weight: 600;">
                        <?= $coupon['is_active'] ? 'Active' : 'Inactive' ?>
                    </span>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <a href="?action=toggle&id=<?= $coupon['id'] ?>" style="color: #2a8f66; text-decoration: none; margin-right: 10px;">Toggle</a>
                    <a href="?action=delete&id=<?= $coupon['id'] ?>" onclick="return confirm('Delete this coupon?')" style="color: #d4604d; text-decoration: none;">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($coupons)): ?>
        <p style="text-align: center; color: #999; padding: 40px;">No coupons created yet.</p>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
