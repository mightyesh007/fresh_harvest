<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$counts = [];
$counts['categories'] = $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
$counts['products'] = $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$counts['orders'] = $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$counts['users'] = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$counts['registered_users'] = $pdo->query('SELECT COUNT(*) FROM users WHERE is_registered = TRUE')->fetchColumn();

// Additional statistics
$stats = [];
$stats['total_revenue'] = $pdo->query('SELECT SUM(total_amount) FROM orders WHERE status = "Completed"')->fetchColumn() ?: 0;
$stats['pending_orders'] = $pdo->query('SELECT COUNT(*) FROM orders WHERE status = "Pending"')->fetchColumn();
$stats['completed_orders'] = $pdo->query('SELECT COUNT(*) FROM orders WHERE status = "Completed"')->fetchColumn();
$stats['monthly_revenue'] = $pdo->query('SELECT SUM(total_amount) FROM orders WHERE status = "Completed" AND MONTH(created_at) = MONTH(CURRENT_DATE) AND YEAR(created_at) = YEAR(CURRENT_DATE)')->fetchColumn() ?: 0;

// Recent orders
$recent_orders = $pdo->query('SELECT o.*, u.name AS user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5')->fetchAll();

// Top selling products
$top_products = $pdo->query('
    SELECT p.name, SUM(oi.quantity) as total_sold, SUM(oi.price * oi.quantity) as revenue
    FROM products p
    JOIN order_items oi ON p.id = oi.product_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = "Completed"
    GROUP BY p.id, p.name
    ORDER BY total_sold DESC
    LIMIT 5
')->fetchAll();
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Dashboard</h2>

    <!-- Statistics Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <span>Categories</span>
            <strong><?= $counts['categories'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Products</span>
            <strong><?= $counts['products'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Total Orders</span>
            <strong><?= $counts['orders'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Total Users</span>
            <strong><?= $counts['users'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Registered Users</span>
            <strong><?= $counts['registered_users'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Completed Orders</span>
            <strong><?= $stats['completed_orders'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Monthly Revenue</span>
            <strong>₹<?= number_format($stats['monthly_revenue'], 2) ?></strong>
        </div>
        <div class="stat-card">
            <span>Total Revenue</span>
            <strong>₹<?= number_format($stats['total_revenue'], 2) ?></strong>
        </div>
    </div>

    <!-- Dashboard Content Grid -->
    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 24px;">

        <!-- Recent Orders -->
        <div class="card">
            <h3>Recent Orders</h3>
            <?php if (empty($recent_orders)): ?>
                <p style="color: #666; margin: 16px 0;">No orders yet.</p>
            <?php else: ?>
                <div style="margin-top: 16px;">
                    <?php foreach ($recent_orders as $order): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #e5e9f0;">
                            <div>
                                <strong>Order #<?= $order['id'] ?></strong><br>
                                <small style="color: #666;"><?= htmlspecialchars($order['user_name']) ?> • <?= date('M j, Y', strtotime($order['created_at'])) ?></small>
                            </div>
                            <div style="text-align: right;">
                                <strong>$<?= number_format($order['total_amount'], 2) ?></strong><br>
                                <span class="tag <?= strtolower($order['status']) ?>" style="font-size: 0.8rem; padding: 4px 8px; border-radius: 4px; background: <?= $order['status'] === 'Completed' ? '#e8f6ea' : '#fff3cd' ?>; color: <?= $order['status'] === 'Completed' ? '#266b3c' : '#856404' ?>;"><?= $order['status'] ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top: 16px;">
                    <a href="orders.php" class="button small">View All Orders</a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Top Products -->
        <div class="card">
            <h3>Top Selling Products</h3>
            <?php if (empty($top_products)): ?>
                <p style="color: #666; margin: 16px 0;">No sales data yet.</p>
            <?php else: ?>
                <div style="margin-top: 16px;">
                    <?php foreach ($top_products as $product): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #e5e9f0;">
                            <div>
                                <strong><?= htmlspecialchars($product['name']) ?></strong><br>
                                <small style="color: #666;"><?= $product['total_sold'] ?> sold</small>
                            </div>
                            <div style="text-align: right;">
                                <strong>₹<?= number_format($product['revenue'], 2) ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top: 16px;">
                    <a href="food.php" class="button small">Manage Products</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card" style="margin-top: 24px;">
        <h3>Quick Actions</h3>
        <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-top: 16px;">
            <a href="food.php" class="button">Add Product</a>
            <a href="categories.php" class="button">Manage Categories</a>
            <a href="orders.php" class="button">View Orders</a>
            <a href="users.php" class="button">Manage Users</a>
        </div>
    </div>

    <div class="panel-note">Use the menu to manage products, categories, users, and orders.</div>
</section>
<?php include 'includes/footer.php'; ?>
