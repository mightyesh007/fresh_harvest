<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: food.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: food.php');
    exit;
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $stock = (int)($_POST['stock'] ?? 0);
    $imagePath = $product['image'];
    $imageUpdated = false;
    
    $_product_image = $_FILES['product_image'] ?? null;
    
    if ($_product_image && $_product_image['error'] === UPLOAD_ERR_OK && $_product_image['size'] > 0) {
        $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $ext = strtolower(pathinfo($_product_image['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($ext, $allowed)) {
            $error = 'Invalid file type. Use JPG, PNG, GIF, WEBP';
        } elseif ($_product_image['size'] > 5 * 1024 * 1024) {
            $error = 'File too large. Max 5MB';
        } else {
            $newFilename = time() . '_' . uniqid() . '.' . $ext;
            $targetPath = $uploadDir . $newFilename;
            
            if (move_uploaded_file($_product_image['tmp_name'], $targetPath)) {
                if ($product['image']) {
                    $oldImagePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . $product['image'];
                    @unlink($oldImagePath);
                }
                $imagePath = 'uploads/' . $newFilename;
                $imageUpdated = true;
            } else {
                $error = 'Upload failed. Check permissions.';
            }
        }
    }
    
    if (!$error && $name && $category_id && $price > 0) {
        $stmt = $pdo->prepare('UPDATE products SET name = ?, category_id = ?, price = ?, description = ?, image = ?, stock = ? WHERE id = ?');
        $stmt->execute([$name, $category_id, $price, $description, $imagePath, $stock, $id]);
        
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        $message = $imageUpdated ? 'Product and image updated!' : 'Product updated!';
    } elseif (!$error) {
        $error = 'Fill required fields (Name, Category, Price)';
    }
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit: <?= htmlspecialchars($product['name']) ?> | Fresh Harvest Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981;
            --primary-dark: #059669;
            --primary-light: #d1fae5;
            --danger: #ef4444;
            --danger-light: #fee2e2;
            --surface: #ffffff;
            --bg: #f8fafc;
            --text: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .header-left h1 {
            font-size: 24px;
            font-weight: 800;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .header-left h1 i {
            color: var(--primary);
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 10px 18px;
            background: var(--surface);
            border-radius: 10px;
            border: 1px solid var(--border);
            transition: all 0.2s;
        }
        
        .back-link:hover {
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
            font-size: 14px;
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert.success {
            background: var(--primary-light);
            color: var(--primary-dark);
            border: 1px solid #a7f3d0;
        }
        
        .alert.error {
            background: var(--danger-light);
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        
        .grid {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 24px;
            align-items: start;
        }
        
        @media (max-width: 768px) {
            .grid { grid-template-columns: 1fr; }
        }
        
        .card {
            background: var(--surface);
            border-radius: 16px;
            padding: 28px;
            box-shadow: var(--shadow);
        }
        
        .card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }
        
        .card-header h2 {
            font-size: 18px;
            font-weight: 700;
        }
        
        .card-header h2 i {
            color: var(--primary);
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        
        @media (max-width: 500px) {
            .form-grid { grid-template-columns: 1fr; }
        }
        
        .form-group {
            margin-bottom: 16px;
        }
        
        .form-group.full {
            grid-column: 1 / -1;
        }
        
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 8px;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.2s;
            background: var(--surface);
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .image-section {
            position: sticky;
            top: 20px;
        }
        
        .current-image-box {
            text-align: center;
            padding: 20px;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            border-radius: 14px;
            margin-bottom: 20px;
        }
        
        .current-image-box .label {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .current-image-box img {
            width: 100%;
            max-height: 200px;
            object-fit: contain;
            border-radius: 10px;
            background: white;
        }
        
        .image-upload-area {
            border: 2px dashed var(--border);
            border-radius: 14px;
            padding: 30px 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            background: #fafafa;
        }
        
        .image-upload-area:hover,
        .image-upload-area.dragover {
            border-color: var(--primary);
            background: var(--primary-light);
        }
        
        .image-upload-area i {
            font-size: 40px;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .image-upload-area p {
            font-size: 14px;
            color: var(--text-muted);
            margin-bottom: 4px;
        }
        
        .image-upload-area small {
            font-size: 12px;
            color: #94a3b8;
        }
        
        .image-preview {
            display: none;
            margin-top: 16px;
            text-align: center;
            padding: 16px;
            background: var(--primary-light);
            border-radius: 12px;
        }
        
        .image-preview.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .image-preview img {
            max-width: 120px;
            max-height: 120px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: var(--shadow);
        }
        
        .btn-remove-img {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 16px;
            background: var(--danger);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-remove-img:hover {
            background: #dc2626;
        }
        
        .btn-save {
            width: 100%;
            padding: 14px 24px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.35);
        }
        
        .hint-box {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 14px 16px;
            background: #fef3c7;
            border-radius: 10px;
            font-size: 13px;
            color: #92400e;
            margin-top: 16px;
        }
        
        .hint-box i {
            margin-top: 2px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/navbar.php'; ?>
    
    <div class="container">
        <div class="header">
            <div class="header-left">
                <h1><i class="fas fa-pen-to-square"></i> Edit Product</h1>
            </div>
            <a href="food.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Products
            </a>
        </div>
        
        <?php if ($message): ?>
            <div class="alert success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert error">
                <i class="fas fa-exclamation-circle"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data" id="productForm">
            <div class="grid">
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-box"></i> Product Details</h2>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Product Name *</label>
                            <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required placeholder="Enter product name">
                        </div>
                        
                        <div class="form-group">
                            <label>Category *</label>
                            <select name="category_id" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $product['category_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Price (₹) *</label>
                            <input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" required placeholder="0.00">
                        </div>
                        
                        <div class="form-group">
                            <label>Stock Quantity</label>
                            <input type="number" name="stock" value="<?= $product['stock'] ?? 0 ?>" min="0" placeholder="0">
                        </div>
                        
                        <div class="form-group full">
                            <label>Description</label>
                            <textarea name="description" placeholder="Product description..."><?= htmlspecialchars($product['description']) ?></textarea>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-save">
                        <i class="fas fa-check"></i> Save Changes
                    </button>
                </div>
                
                <div class="card image-section">
                    <div class="card-header">
                        <h2><i class="fas fa-image"></i> Product Image</h2>
                    </div>
                    
                    <div class="current-image-box">
                        <div class="label">Current Image</div>
                        <img src="../<?= htmlspecialchars($product['image'] ?: 'uploads/no-image.png') ?>" alt="<?= htmlspecialchars($product['name']) ?>" id="currentImg">
                    </div>
                    
                    <div class="image-upload-area" id="uploadArea" onclick="document.getElementById('fileInput').click()">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Drop new image or click to browse</p>
                        <small>JPG, PNG, GIF, WEBP (Max 5MB)</small>
                        <input type="file" id="fileInput" name="product_image" accept="image/*" style="display:none">
                    </div>
                    
                    <div class="image-preview" id="imagePreview">
                        <img id="previewImg" src="#" alt="Preview">
                        <br>
                        <button type="button" class="btn-remove-img" onclick="clearImage()">
                            <i class="fas fa-times"></i> Remove
                        </button>
                    </div>
                    
                    <div class="hint-box">
                        <i class="fas fa-lightbulb"></i>
                        <span>New image will replace current one after saving.</span>
                    </div>
                </div>
            </div>
        </form>
    </div>
    
    <script>
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const imagePreview = document.getElementById('imagePreview');
        const previewImg = document.getElementById('previewImg');
        
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    imagePreview.classList.add('show');
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function clearImage() {
            fileInput.value = '';
            imagePreview.classList.remove('show');
            previewImg.src = '#';
        }
        
        // File input change
        fileInput.addEventListener('change', function() {
            previewImage(this);
        });
        
        // Drag and drop
        if (uploadArea) {
            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
                if (e.dataTransfer.files.length > 0) {
                    fileInput.files = e.dataTransfer.files;
                    previewImage(fileInput);
                }
            });
        }
    </script>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>