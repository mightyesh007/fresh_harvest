<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = '';
$error = '';
$uploadError = null;
$imagePath = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = (int) ($_POST['category_id'] ?? 0);
    $price = (float) ($_POST['price'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $stock = (int) ($_POST['stock'] ?? 0);
    
    $_product_image = $_FILES['product_image'] ?? null;

    if ($_product_image && $_product_image['error'] === UPLOAD_ERR_OK) {
        $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
        if (!is_dir($uploadDir)) {
            if (!mkdir($uploadDir, 0777, true)) {
                $uploadError = 'Failed to create uploads directory';
            }
        }
        
        if (!$uploadError && is_dir($uploadDir) && is_writable($uploadDir)) {
            $ext = strtolower(pathinfo($_product_image['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (!in_array($ext, $allowed)) {
                $uploadError = 'Invalid file type. Use JPG, PNG, GIF, or WEBP';
            } elseif ($_product_image['size'] > 5 * 1024 * 1024) {
                $uploadError = 'File too large. Maximum 5MB allowed';
            } else {
                $newFilename = time() . '_' . uniqid() . '.' . $ext;
                $targetPath = $uploadDir . $newFilename;
                if (move_uploaded_file($_product_image['tmp_name'], $targetPath)) {
                    $imagePath = 'uploads/' . $newFilename;
                } else {
                    $uploadError = 'Failed to save image';
                }
            }
        } elseif (!$uploadError) {
            $uploadError = 'Uploads directory is not writable';
        }
    } elseif ($_product_image && $_product_image['error'] !== UPLOAD_ERR_NO_FILE) {
        $uploadErrors = [
            UPLOAD_ERR_INI_SIZE => 'File too large',
            UPLOAD_ERR_FORM_SIZE => 'File too large',
            UPLOAD_ERR_PARTIAL => 'File partially uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder',
            UPLOAD_ERR_CANT_WRITE => 'Cannot write file',
        ];
        $uploadError = $uploadErrors[$_product_image['error']] ?? 'Upload error';
    }

    if ($name && $category_id && $price) {
        $stmt = $pdo->prepare('INSERT INTO products (name, category_id, price, description, image, stock) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$name, $category_id, $price, $description, $imagePath, $stock]);
        $message = 'Product added successfully!';
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    if ($product) {
        $imagePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . $product['image'];
        if ($product && $product['image'] && file_exists($imagePath)) {
            unlink($imagePath);
        }
        $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
        $message = 'Product deleted successfully!';
    }
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$products = $pdo->query('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management | Fresh Harvest Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #eef2f7 100%);
        }
        
        .products-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px;
        }
        
        /* Header Section */
        .products-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-title h1 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #1e3c32, #2a8f66);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .header-title p {
            color: #64748b;
            margin-top: 5px;
            font-size: 14px;
        }
        
        .stats-cards {
            display: flex;
            gap: 15px;
        }
        
        .stat-card {
            background: white;
            padding: 12px 24px;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            text-align: center;
        }
        
        .stat-card .number {
            font-size: 24px;
            font-weight: 800;
            color: #2a8f66;
        }
        
        .stat-card .label {
            font-size: 12px;
            color: #64748b;
        }
        
        /* Alert Messages */
        .alert {
            padding: 16px 20px;
            border-radius: 14px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            font-weight: 500;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert.success {
            background: linear-gradient(135deg, #dcfce7, #bbf7d0);
            color: #166534;
            border: 1px solid #86efac;
        }
        
        .alert.error {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
        
        /* Add Product Modal Button */
        .btn-add {
            background: linear-gradient(135deg, #2a8f66, #1e6b4a);
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(42, 143, 102, 0.3);
        }
        
        /* Modal Overlay */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 24px;
            width: 90%;
            max-width: 600px;
            max-height: 85vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #94a3b8;
        }
        
        .modal-body {
            padding: 24px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #334155;
            font-size: 13px;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2a8f66;
            box-shadow: 0 0 0 3px rgba(42, 143, 102, 0.1);
        }
        
        /* Image Upload Area */
        .image-upload-box {
            border: 2px dashed #cbd5e1;
            border-radius: 16px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #f8fafc;
            position: relative;
        }
        
        .image-upload-box:hover,
        .image-upload-box.dragover {
            border-color: #2a8f66;
            background: #f0fdf4;
        }
        
        .image-upload-box i {
            font-size: 48px;
            color: #2a8f66;
            margin-bottom: 10px;
        }
        
        .image-upload-box .upload-hint {
            font-size: 13px;
            color: #94a3b8;
            margin-top: 8px;
        }
        
        .image-preview {
            margin-top: 15px;
            display: none;
            padding: 15px;
            background: #f0fdf4;
            border-radius: 12px;
        }
        
        .image-preview.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .image-preview img {
            max-width: 120px;
            max-height: 120px;
            border-radius: 12px;
            object-fit: cover;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .image-preview .preview-info {
            font-size: 12px;
            color: #64748b;
            margin-top: 8px;
        }
        
        .btn-remove-image {
            background: #ef4444;
            color: white;
            border: none;
            padding: 6px 14px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.2s;
        }
        
        .btn-remove-image:hover {
            background: #dc2626;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #2a8f66, #1e6b4a);
            color: white;
            border: none;
            padding: 14px 24px;
            border-radius: 12px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
            position: relative;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(42, 143, 102, 0.3);
        }
        
        .btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }
        
        .btn-submit .spinner {
            display: none;
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        .btn-submit.loading .btn-text { display: none; }
        .btn-submit.loading .spinner { display: inline-block; }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Products Grid */
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 24px;
            margin-top: 30px;
        }
        
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
        }
        
        .product-image {
            position: relative;
            height: 220px;
            overflow: hidden;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s;
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.05);
        }
        
        .stock-badge {
            position: absolute;
            top: 12px;
            right: 12px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .stock-badge.in-stock { color: #2a8f66; }
        .stock-badge.low-stock { color: #f59e0b; }
        .stock-badge.out-stock { color: #ef4444; }
        
        .product-info {
            padding: 18px;
        }
        
        .product-title {
            font-size: 16px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 5px;
        }
        
        .product-category {
            font-size: 12px;
            color: #2a8f66;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .product-price {
            font-size: 22px;
            font-weight: 800;
            color: #2a8f66;
            margin: 10px 0;
        }
        
        .product-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e2e8f0;
        }
        
        .btn-edit, .btn-delete {
            flex: 1;
            padding: 8px;
            border-radius: 10px;
            text-align: center;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-edit {
            background: #e8f6ea;
            color: #2a8f66;
        }
        
        .btn-edit:hover {
            background: #2a8f66;
            color: white;
        }
        
        .btn-delete {
            background: #fee2e2;
            color: #ef4444;
        }
        
        .btn-delete:hover {
            background: #ef4444;
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px;
            background: white;
            border-radius: 24px;
        }
        
        .empty-state i {
            font-size: 80px;
            color: #cbd5e1;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .products-container { padding: 15px; }
            .products-header { flex-direction: column; align-items: flex-start; }
            .products-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/navbar.php'; ?>
    
    <div class="products-container">
        <div class="products-header">
            <div class="header-title">
                <h1><i class="fas fa-box"></i> Product Management</h1>
                <p>Manage your store inventory, add new products, and track stock</p>
            </div>
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="number"><?= count($products) ?></div>
                    <div class="label">Total Products</div>
                </div>
                <div class="stat-card">
                    <div class="number"><?= count($categories) ?></div>
                    <div class="label">Categories</div>
                </div>
                <button class="btn-add" onclick="openModal()">
                    <i class="fas fa-plus"></i> Add New Product
                </button>
            </div>
        </div>
        
        <?php if ($message): ?>
            <div class="alert success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error || $uploadError): ?>
            <div class="alert error">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error ?: $uploadError) ?>
            </div>
        <?php endif; ?>
        
        <!-- Products Grid -->
        <?php if (empty($products)): ?>
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <h3>No Products Yet</h3>
                <p>Click the "Add New Product" button to create your first product.</p>
            </div>
        <?php else: ?>
            <div class="products-grid">
                <?php foreach ($products as $product): ?>
                <div class="product-card">
                    <div class="product-image">
                        <img src="../<?= htmlspecialchars($product['image'] ?: 'uploads/no-image.png') ?>" alt="<?= htmlspecialchars($product['name']) ?>" onerror="this.src='../assets/images/carrot.jpeg'">
                        <?php 
                        $stockClass = 'in-stock';
                        $stockText = 'In Stock';
                        if (($product['stock'] ?? 0) <= 0) {
                            $stockClass = 'out-stock';
                            $stockText = 'Out of Stock';
                        } elseif (($product['stock'] ?? 0) <= 10) {
                            $stockClass = 'low-stock';
                            $stockText = 'Low Stock';
                        }
                        ?>
                        <span class="stock-badge <?= $stockClass ?>"><?= $stockText ?> (<?= $product['stock'] ?? 0 ?>)</span>
                    </div>
                    <div class="product-info">
                        <div class="product-title"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-category"><i class="fas fa-tag"></i> <?= htmlspecialchars($product['category_name'] ?: 'Uncategorized') ?></div>
                        <div class="product-price">₹<?= number_format($product['price'], 2) ?></div>
                        <div class="product-actions">
                            <a href="edit-product.php?id=<?= $product['id'] ?>" class="btn-edit"><i class="fas fa-edit"></i> Edit</a>
                            <a href="food.php?delete=<?= $product['id'] ?>" class="btn-delete" onclick="return confirm('Delete this product?')"><i class="fas fa-trash"></i> Delete</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Add Product Modal -->
    <div id="addProductModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> Add New Product</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form method="post" enctype="multipart/form-data" id="addProductForm">
                    <div class="form-group">
                        <label><i class="fas fa-font"></i> Product Name</label>
                        <input type="text" name="name" placeholder="e.g., Organic Fresh Apples" required>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-folder"></i> Category</label>
                        <select name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                            <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-rupee-sign"></i> Price (₹)</label>
                        <input type="number" step="0.01" name="price" placeholder="0.00" required>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-boxes"></i> Stock Quantity</label>
                        <input type="number" name="stock" value="100" min="0">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-align-left"></i> Description</label>
                        <textarea name="description" rows="3" placeholder="Product description..."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-image"></i> Product Image</label>
                        <div class="image-upload-box" id="uploadBox" onclick="document.getElementById('productImage').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Drag & drop or click to upload</p>
                            <small class="upload-hint">Supports: JPG, PNG, GIF, WEBP (Max 5MB)</small>
                            <input type="file" id="productImage" name="product_image" accept="image/*" style="display: none;" onchange="previewImage(this)">
                        </div>
                        <div class="image-preview" id="imagePreview">
                            <img id="previewImg" src="#" alt="Preview">
                            <p class="preview-info"></p>
                            <button type="button" class="btn-remove-image" onclick="clearImage()"><i class="fas fa-times"></i> Remove</button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-submit" id="submitBtn" onclick="this.classList.add('loading')">
                            <span class="btn-text"><i class="fas fa-save"></i> Save Product</span>
                            <span class="spinner"></span>
                        </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function openModal() {
            document.getElementById('addProductModal').classList.add('active');
        }
        
        function closeModal() {
            document.getElementById('addProductModal').classList.remove('active');
            document.getElementById('addProductForm').reset();
            document.getElementById('imagePreview').classList.remove('active');
            document.getElementById('previewImg').src = '#';
        }
        
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            const previewImg = document.getElementById('previewImg');
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    preview.classList.add('active');
                    const info = document.querySelector('.image-preview .preview-info');
                    if (info) info.textContent = file.name + ' (' + fileSizeMB + 'MB)';
                };
                reader.readAsDataURL(file);
            }
        }
        
        function clearImage() {
            document.getElementById('productImage').value = '';
            document.getElementById('imagePreview').classList.remove('active');
            document.getElementById('previewImg').src = '#';
        }
        
        // Drag and drop support
        const uploadBox = document.querySelector('.image-upload-box');
        const fileInput = document.getElementById('productImage');
        
        if (uploadBox && fileInput) {
            uploadBox.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('dragover');
            });
            
            uploadBox.addEventListener('dragleave', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
            });
            
            uploadBox.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    fileInput.files = files;
                    previewImage(fileInput);
                }
            });
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('addProductModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>