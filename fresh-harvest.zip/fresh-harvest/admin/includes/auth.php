<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* 🔒 Disable cache */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

/* ❗ Check login - redirect if not logged in */
if (empty($_SESSION['admin_logged_in'])) {
    $current_file = basename($_SERVER['PHP_SELF']);
    if ($current_file !== 'index.php' && $current_file !== 'login.php') {
        header("Location: index.php");
        exit();
    }
}

/* ✅ Mark that user is inside admin */
$_SESSION['inside_admin'] = true;