</main>

<footer>
    <p>Admin Panel</p>
</footer>

<script>
let isAdminNavigation = false;

// Detect clicks inside admin
document.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", function() {
        if (this.href.includes("admin")) {
            isAdminNavigation = true;
        }
    });
});

// Logout if leaving admin
window.addEventListener("beforeunload", function () {
    if (!isAdminNavigation) {
        navigator.sendBeacon("index.php?action=logout");
    }
});
</script>

</body>
</html>