<aside class="admin-sidebar">
    <div class="sidebar-brand">Admin Menu</div>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="food.php">Products</a></li>
        <li><a href="stock.php">Stock Management</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="users.php">Users</a></li>
        <li><a href="coupons.php">Discount Codes</a></li>
        <li><a href="newsletter.php">Newsletter</a></li>
        <li><a href="settings.php">Settings</a></li>
        <li><a href="index.php?action=logout">Logout</a></li>
    </ul>
</aside>
