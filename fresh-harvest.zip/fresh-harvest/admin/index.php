<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/db.php';

/* 🔒 Disable cache */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

/* Already logged in? Redirect to dashboard */
if (!empty($_SESSION['admin_logged_in'])) {
    header('Location: dashboard.php');
    exit();
}

/* Logout handling */
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM admins WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        $passwordValid = false;

        if ($admin) {
            /* Check if password is hashed or plain text */
            if (strpos($admin['password'], '$') === 0) {
                $passwordValid = password_verify($password, $admin['password']);
            } else {
                $passwordValid = ($admin['password'] === $password);
            }
        }

        if ($passwordValid) {
            /* Set session variables */
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['inside_admin'] = true;

            header('Location: dashboard.php');
            exit;
        }

        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body.auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e3c32 0%, #2a8f66 100%);
            font-family: 'Inter', sans-serif;
        }
        .auth-container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .auth-container h1 {
            color: #1e3c32;
            margin-bottom: 30px;
            font-size: 28px;
        }
        .auth-form label {
            display: block;
            text-align: left;
            margin-bottom: 6px;
            color: #475569;
            font-weight: 600;
            font-size: 14px;
        }
        .auth-form input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            margin-bottom: 16px;
            font-size: 15px;
            transition: all 0.3s;
        }
        .auth-form input:focus {
            outline: none;
            border-color: #2a8f66;
            box-shadow: 0 0 0 3px rgba(42, 143, 102, 0.15);
        }
        .auth-form button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #2a8f66, #1e6b4a);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }
        .auth-form button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(42, 143, 102, 0.35);
        }
        .alert.error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: left;
        }
    </style>
</head>
<body class="auth-page">
    <div class="auth-container">
        <h1>Fresh Harvest<br><small style="font-size: 14px; color: #64748b;">Admin Panel</small></h1>

        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post" class="auth-form">
            <label>Username</label>
            <input type="text" name="username" required autocomplete="username">

            <label>Password</label>
            <input type="password" name="password" required autocomplete="current-password">

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>