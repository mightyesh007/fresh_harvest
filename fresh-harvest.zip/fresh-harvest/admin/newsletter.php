<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$message = '';
$action = $_GET['action'] ?? '';

// Delete subscriber
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $pdo->prepare('DELETE FROM newsletter WHERE id = ?')->execute([$id]);
    header('Location: newsletter.php');
    exit;
}

// Toggle subscription status
if ($action === 'toggle' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare('SELECT is_active FROM newsletter WHERE id = ?');
    $stmt->execute([$id]);
    $sub = $stmt->fetch();
    if ($sub) {
        $pdo->prepare('UPDATE newsletter SET is_active = ? WHERE id = ?')->execute([!$sub['is_active'], $id]);
    }
    header('Location: newsletter.php');
    exit;
}

// Export subscribers
if ($action === 'export') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="newsletter_subscribers.csv"');

    $subscribers = $pdo->query('SELECT email, subscribed_at, is_active FROM newsletter ORDER BY subscribed_at DESC')->fetchAll();

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Email', 'Subscribed At', 'Status']);

    foreach ($subscribers as $sub) {
        fputcsv($output, [
            $sub['email'],
            $sub['subscribed_at'],
            $sub['is_active'] ? 'Active' : 'Inactive'
        ]);
    }
    fclose($output);
    exit;
}

// Get subscribers
$subscribers = $pdo->query('SELECT * FROM newsletter ORDER BY subscribed_at DESC')->fetchAll();

// Statistics
$stats = [];
$stats['total'] = count($subscribers);
$stats['active'] = count(array_filter($subscribers, fn($s) => $s['is_active']));
$stats['inactive'] = $stats['total'] - $stats['active'];
$stats['this_month'] = count(array_filter($subscribers, fn($s) => date('Y-m', strtotime($s['subscribed_at'])) === date('Y-m')));
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Newsletter Management</h2>

    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'Error') === false ? 'success' : 'error' ?>" style="margin-bottom: 20px;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card">
            <span>Total Subscribers</span>
            <strong><?= $stats['total'] ?></strong>
        </div>
        <div class="stat-card" style="border-left: 4px solid #4caf50;">
            <span>Active Subscribers</span>
            <strong style="color: #4caf50;"><?= $stats['active'] ?></strong>
        </div>
        <div class="stat-card" style="border-left: 4px solid #f44336;">
            <span>Inactive Subscribers</span>
            <strong style="color: #f44336;"><?= $stats['inactive'] ?></strong>
        </div>
        <div class="stat-card" style="border-left: 4px solid #2196f3;">
            <span>This Month</span>
            <strong style="color: #2196f3;"><?= $stats['this_month'] ?></strong>
        </div>
    </div>

    <!-- Actions -->
    <div style="background: #f3f7f6; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
        <h3 style="margin-top: 0;">Newsletter Actions</h3>
        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
            <a href="?action=export" style="background: #2a8f66; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 600;">Export Subscribers (CSV)</a>
            <button onclick="sendNewsletter()" style="background: #ff9800; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">Send Newsletter</button>
        </div>
    </div>

    <!-- Subscribers Table -->
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #f3f7f6;">
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Email Address</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Subscribed Date</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Status</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subscribers as $subscriber): ?>
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px;">
                    <strong><?= htmlspecialchars($subscriber['email']) ?></strong>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <?= date('M d, Y', strtotime($subscriber['subscribed_at'])) ?>
                    <div style="font-size: 12px; color: #999; margin-top: 2px;">
                        <?= date('H:i', strtotime($subscriber['subscribed_at'])) ?>
                    </div>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <span style="<?= $subscriber['is_active'] ? 'color: #4caf50;' : 'color: #f44336;' ?> font-weight: 600;">
                        <?= $subscriber['is_active'] ? 'Active' : 'Inactive' ?>
                    </span>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <a href="?action=toggle&id=<?= $subscriber['id'] ?>" style="color: #2a8f66; text-decoration: none; margin-right: 10px;">Toggle</a>
                    <a href="?action=delete&id=<?= $subscriber['id'] ?>" onclick="return confirm('Remove this subscriber?')" style="color: #d4604d; text-decoration: none;">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($subscribers)): ?>
        <p style="text-align: center; color: #999; padding: 40px;">No newsletter subscribers yet.</p>
    <?php endif; ?>
</section>

<script>
function sendNewsletter() {
    const subject = prompt('Enter newsletter subject:');
    if (!subject) return;

    const content = prompt('Enter newsletter content:');
    if (!content) return;

    // In a real application, you would send emails here
    alert('Newsletter feature would send emails to ' + <?= $stats['active'] ?> + ' active subscribers.\n\nSubject: ' + subject + '\n\nContent: ' + content.substring(0, 100) + '...');
}
</script>

<?php include 'includes/footer.php'; ?>
