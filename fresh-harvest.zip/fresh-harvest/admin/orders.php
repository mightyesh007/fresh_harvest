<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

if (isset($_GET['complete'])) {
    $id = (int) $_GET['complete'];
    $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute(['Completed', $id]);
    header('Location: orders.php');
    exit;
}

$orders = $pdo->query('SELECT o.*, u.name AS user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC')->fetchAll();
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Orders</h2>
    <table class="data-table">
        <thead>
            <tr><th>ID</th><th>User</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?= $order['id'] ?></td>
                <td><?= htmlspecialchars($order['user_name']) ?></td>
                <td>₹<?= number_format($order['total_amount'], 2) ?></td>
                <td><?= htmlspecialchars($order['status']) ?></td>
                <td><?= htmlspecialchars($order['created_at']) ?></td>
                <td>
                    <?php if ($order['status'] !== 'Completed'): ?>
                        <a class="button small" href="orders.php?complete=<?= $order['id'] ?>">Mark Completed</a>
                    <?php else: ?>
                        <span class="tag completed">Completed</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php include 'includes/footer.php'; ?>
