<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name'] ?? 'Fresh Harvest');
    $admin_email = trim($_POST['admin_email'] ?? 'admin@freshharvest.local');
    $stmt = $pdo->prepare('INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)');
    $stmt->execute(['site_name', $site_name]);
    $stmt->execute(['admin_email', $admin_email]);
    $message = 'Settings updated successfully.';
}

$settings = [];
$stmt = $pdo->query('SELECT `key`, `value` FROM settings');
foreach ($stmt->fetchAll() as $row) {
    $settings[$row['key']] = $row['value'];
}
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Settings</h2>
    <?php if ($message): ?><div class="alert success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <form method="post" class="form-grid">
        <label>Site Name</label>
        <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? 'Fresh Harvest') ?>" required>
        <label>Admin Email</label>
        <input type="email" name="admin_email" value="<?= htmlspecialchars($settings['admin_email'] ?? 'admin@freshharvest.local') ?>" required>
        <button type="submit">Save Settings</button>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
