<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$message = '';
$action = $_GET['action'] ?? '';

// Update stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_stock'])) {
    $productId = (int) $_POST['product_id'];
    $newStock = max(0, (int) $_POST['stock']);

    try {
        $pdo->prepare('UPDATE products SET stock = ? WHERE id = ?')->execute([$newStock, $productId]);
        $message = 'Stock updated successfully!';
    } catch (Exception $e) {
        $message = 'Error updating stock: ' . $e->getMessage();
    }
}

// Bulk update stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_update'])) {
    $updates = $_POST['stock_updates'] ?? [];
    $updated = 0;

    foreach ($updates as $productId => $stock) {
        $stock = max(0, (int) $stock);
        try {
            $pdo->prepare('UPDATE products SET stock = ? WHERE id = ?')->execute([$stock, $productId]);
            $updated++;
        } catch (Exception $e) {
            // Continue with other updates
        }
    }

    $message = "Updated stock for $updated product(s)!";
}

// Get products with stock info
$products = $pdo->query('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.stock ASC, p.name ASC')->fetchAll();

// Stock statistics
$stats = [];
$stats['total_products'] = count($products);
$stats['out_of_stock'] = count(array_filter($products, fn($p) => $p['stock'] == 0));
$stats['low_stock'] = count(array_filter($products, fn($p) => $p['stock'] > 0 && $p['stock'] <= 10));
$stats['total_stock'] = array_sum(array_column($products, 'stock'));
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Stock Management</h2>

    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'Error') === false ? 'success' : 'error' ?>" style="margin-bottom: 20px;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Stock Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card">
            <span>Total Products</span>
            <strong><?= $stats['total_products'] ?></strong>
        </div>
        <div class="stat-card" style="border-left: 4px solid #f44336;">
            <span>Out of Stock</span>
            <strong style="color: #f44336;"><?= $stats['out_of_stock'] ?></strong>
        </div>
        <div class="stat-card" style="border-left: 4px solid #ff9800;">
            <span>Low Stock (≤10)</span>
            <strong style="color: #ff9800;"><?= $stats['low_stock'] ?></strong>
        </div>
        <div class="stat-card">
            <span>Total Stock Units</span>
            <strong><?= $stats['total_stock'] ?></strong>
        </div>
    </div>

    <!-- Bulk Update Form -->
    <div style="background: #f3f7f6; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
        <h3 style="margin-top: 0;">Bulk Stock Update</h3>
        <form method="post">
            <p style="margin-bottom: 15px; color: #666;">Update multiple products at once. Leave fields empty to keep current values.</p>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 15px;">
                <?php foreach ($products as $product): ?>
                <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #ddd;">
                    <strong style="display: block; margin-bottom: 8px;"><?= htmlspecialchars($product['name']) ?></strong>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <label style="font-size: 14px; color: #666;">Current: <strong><?= $product['stock'] ?></strong></label>
                        <input type="number" name="stock_updates[<?= $product['id'] ?>]" placeholder="New stock" min="0" style="flex: 1; padding: 6px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" name="bulk_update" style="background: #2a8f66; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">Update All Stock</button>
        </form>
    </div>

    <!-- Individual Stock Management -->
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #f3f7f6;">
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Product</th>
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Category</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Current Stock</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Status</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;">Update Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $product): ?>
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <img src="../<?= htmlspecialchars($product['image']) ?>" alt="" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px;">
                        <div>
                            <strong><?= htmlspecialchars($product['name']) ?></strong>
                            <div style="font-size: 12px; color: #666;">₹<?= number_format($product['price'], 2) ?></div>
                        </div>
                    </div>
                </td>
                <td style="padding: 12px;"><?= htmlspecialchars($product['category_name'] ?: 'Uncategorized') ?></td>
                <td style="padding: 12px; text-align: center;">
                    <strong style="font-size: 16px; <?= $product['stock'] == 0 ? 'color: #f44336;' : ($product['stock'] <= 10 ? 'color: #ff9800;' : 'color: #4caf50;') ?>">
                        <?= $product['stock'] ?>
                    </strong>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <?php if ($product['stock'] == 0): ?>
                        <span style="background: #ffebee; color: #f44336; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">OUT OF STOCK</span>
                    <?php elseif ($product['stock'] <= 10): ?>
                        <span style="background: #fff3e0; color: #ff9800; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">LOW STOCK</span>
                    <?php else: ?>
                        <span style="background: #e8f5e8; color: #4caf50; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">IN STOCK</span>
                    <?php endif; ?>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <input type="number" name="stock" value="<?= $product['stock'] ?>" min="0" style="width: 80px; padding: 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center;">
                        <button type="submit" name="update_stock" style="background: #2a8f66; color: white; padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; margin-left: 5px;">Update</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($products)): ?>
        <p style="text-align: center; color: #999; padding: 40px;">No products found.</p>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
