<?php
/* Start session if not already started */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/db.php';
require_once 'includes/auth.php';

$users = $pdo->query('SELECT * FROM users ORDER BY is_registered DESC, created_at DESC')->fetchAll();
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<section class="admin-panel">
    <h2>Users</h2>
    <div style="margin-bottom: 20px;">
        <p><strong>Registered Users:</strong> <?= count(array_filter($users, fn($u) => $u['is_registered'])) ?> | <strong>Guest Users:</strong> <?= count(array_filter($users, fn($u) => !$u['is_registered'])) ?></p>
    </div>
    <table class="data-table">
        <thead>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Type</th><th>Joined</th></tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['phone'] ?: 'N/A') ?></td>
                <td>
                    <?php if ($user['is_registered']): ?>
                        <span class="tag" style="background: #e8f6ea; color: #266b3c;">Registered</span>
                    <?php else: ?>
                        <span class="tag" style="background: #fff3cd; color: #856404;">Guest</span>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($user['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php include 'includes/footer.php'; ?>
