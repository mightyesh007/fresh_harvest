CREATE DATABASE IF NOT EXISTS fresh_harvest DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fresh_harvest;

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(40),
    address TEXT,
    password VARCHAR(255),
    is_registered BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Add new columns to existing users table if they don't exist
ALTER TABLE users ADD COLUMN IF NOT EXISTS password VARCHAR(255);
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_registered BOOLEAN DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category_id INT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    description TEXT,
    image VARCHAR(255) DEFAULT 'assets/images/logo.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
    `key` VARCHAR(100) NOT NULL PRIMARY KEY,
    `value` TEXT NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO admins (name, username, password) VALUES
('Super Admin', 'admin', 'admin123');

INSERT IGNORE INTO categories (name) VALUES
('Fruits'),
('Vegetables'),
('Herbs'),
('Organic');

INSERT IGNORE INTO products (name, category_id, price, description, image) VALUES
('Fresh Red Apples', 1, 89, 'Crisp and juicy red apples perfect for healthy snacks. Sourced from premium orchards.', 'assets/images/red-apple.png'),
('Golden Bananas', 1, 45, 'Perfectly ripe bananas rich in potassium. Great for smoothies or as-is.', 'assets/images/banana.png'),
('Fresh Oranges', 1, 99, 'Sweet and tangy oranges loaded with vitamin C. Fresh from the grove.', 'assets/images/orange.png'),
('Organic Strawberries', 1, 120, 'Delicious red strawberries bursting with natural sweetness. Hand-picked daily.', 'assets/images/strawberry.png'),
('Ripe Mangoes', 1, 150, 'Premium quality mangoes at peak ripeness. The king of fruits.', 'assets/images/mango.png'),
('Green Spinach', 2, 65, 'Fresh spinach leaves from local organic farms. Rich in iron and nutrients.', 'assets/images/spinach.png'),
('Cherry Tomatoes', 2, 85, 'Sweet salad tomatoes packed with flavor. Perfect for salads and cooking.', 'assets/images/tomato.png'),
('Organic Carrots', 4, 75, 'Crunchy orange carrots full of nutrients. Clean and ready to eat.', 'assets/images/carrot.png'),
('Bell Peppers Mix', 2, 95, 'Colorful bell peppers in red, green, and yellow. Crisp and flavorful.', 'assets/images/bell-pepper.png'),
('Fresh Broccoli', 2, 80, 'Vibrant green broccoli florets. Packed with vitamins and minerals.', 'assets/images/broccoli.png'),
('Organic Basil', 3, 40, 'Fresh aromatic basil leaves. Perfect for cooking and garnishing.', 'assets/images/basil.png'),
('Green Mint Leaves', 3, 35, 'Refreshing mint leaves for teas and beverages. Fragrant and pure.', 'assets/images/mint.png'),
('Garlic Bulbs', 2, 60, 'Fresh garlic bulbs with strong aroma. Essential spice for cooking.', 'assets/images/garlic.png'),
('Onions Fresh', 2, 50, 'Golden onions perfect for all your cooking needs. Clean and ready to use.', 'assets/images/onion.png'),
('Organic Potatoes', 4, 55, 'Earthy potatoes grown organically. Versatile for all recipes.', 'assets/images/potato.png'),
('Fresh Cucumbers', 2, 70, 'Crisp cool cucumbers. Great for salads and hydration.', 'assets/images/cucumber.png'),
('Green Peas', 2, 90, 'Fresh green peas from the pod. Tender and sweet.', 'assets/images/peas.png'),
('Organic Lettuce', 4, 75, 'Fresh lettuce leaves for healthy salads. Grown without chemicals.', 'assets/images/lettuce.png'),
('Radishes Bundle', 2, 45, 'Red radishes with peppery crunch. Fresh and crunchy.', 'assets/images/radish.png'),
('Beets Fresh', 2, 65, 'Earthy beets full of nutrition. Great for juices and cooking.', 'assets/images/beet.png');

INSERT IGNORE INTO settings (`key`, `value`) VALUES
('site_name', 'Fresh Harvest'),
('admin_email', 'admin@freshharvest.local');

-- Reviews and Ratings
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_review (product_id, user_id)
) ENGINE=InnoDB;

-- Wishlist
CREATE TABLE IF NOT EXISTS wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_wishlist (user_id, product_id)
) ENGINE=InnoDB;

-- Coupons and Discount Codes
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_type VARCHAR(20) NOT NULL DEFAULT 'percentage',
    discount_value DECIMAL(10,2) NOT NULL,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    max_usage INT DEFAULT NULL,
    usage_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    valid_from TIMESTAMP NOT NULL,
    valid_until TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Applied Coupons on Orders
CREATE TABLE IF NOT EXISTS order_coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    coupon_id INT NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Add stock column to products table if not exists
ALTER TABLE products ADD COLUMN IF NOT EXISTS stock INT DEFAULT 100;

-- Sample coupons
INSERT IGNORE INTO coupons (code, discount_type, discount_value, min_order_amount, valid_from, valid_until, is_active) VALUES
('WELCOME10', 'percentage', 10, 0, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), TRUE),
('FRESH50', 'flat', 50, 500, NOW(), DATE_ADD(NOW(), INTERVAL 60 DAY), TRUE),
('ORGANIC15', 'percentage', 15, 0, NOW(), DATE_ADD(NOW(), INTERVAL 90 DAY), TRUE);
-- Newsletter Subscriptions
CREATE TABLE IF NOT EXISTS newsletter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT TRUE,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;