This directory stores uploaded product images.

Uploaded files are automatically generated with timestamps and stored here.
Users should not manually add files to this directory.

File structure:
- {timestamp}_{originalfilename}.jpg
- Example: 1680000000_apple.jpg

The uploads folder requires write permissions for the web server (typically www-data or IUSR).
