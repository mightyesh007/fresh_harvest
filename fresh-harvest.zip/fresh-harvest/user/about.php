<?php
require_once '../config/db.php';
session_start();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subscribe_newsletter'])) {
    $email = trim($_POST['newsletter_email']);
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $stmt = $pdo->prepare('INSERT IGNORE INTO newsletter (email) VALUES (?)');
            $stmt->execute([$email]);
            $message = 'Thank you for subscribing! You\'ll receive our latest updates and offers.';
        } catch (Exception $e) {
            $message = 'Subscription failed. Please try again.';
        }
    } else {
        $message = 'Please enter a valid email address.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%232a8f66'/><text x='50' y='70' font-size='60' font-weight='bold' fill='white' text-anchor='middle'>F</text></svg>">
    <style>
        .product-image { display: block; width: 100%; height: auto; }
        .product-image.loading { opacity: 0.5; }
        .hero { 
            background: linear-gradient(rgba(42, 143, 102, 0.25), rgba(42, 143, 102, 0.35)), 
            url('../assets/images/aboutb.jpeg'); 
            background-size: cover; 
            background-position: center center;
            min-height: 400px;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.width = '100%';
                fallback.style.aspectRatio = '1';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontWeight = '500';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('.product-image').forEach(img => {
                img.addEventListener('error', function() { handleImageError(this); });
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="hero">
            <h1>About Fresh Harvest</h1>
            <p>Your trusted source for fresh, locally-sourced produce delivered right to your door.</p>
        </section>

        <?php if ($message): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 6px; margin-bottom: 30px; border: 1px solid #c3e6cb;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <section class="product-section">
            <h2>Our Story</h2>
            <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 40px; align-items: center;">
                <div>
                    <p>Fresh Harvest was founded with a simple mission: to connect local farmers with health-conscious consumers who value quality and freshness above all else.</p>
                    <p>We work directly with local growers to bring you the freshest fruits and vegetables, harvested at peak ripeness and delivered within hours of picking. Our commitment to sustainability and supporting local agriculture sets us apart from other food delivery services.</p>
                    <p>Every product in our catalog is carefully selected for its quality, nutritional value, and taste. We believe that great food starts with great ingredients, and we're proud to be part of your journey toward healthier eating.</p>
                </div>
                <div>
                    <div style="background: #f3f7f6; padding: 40px; border-radius: 16px; text-align: center;">
                        <h3 style="color: #2a8f66; margin-bottom: 20px;">Why Choose Fresh Harvest?</h3>
                        <ul style="list-style: none; padding: 0; text-align: left;">
                            <li style="margin-bottom: 12px; padding-left: 24px; position: relative;">✓ Locally sourced produce</li>
                            <li style="margin-bottom: 12px; padding-left: 24px; position: relative;">✓ Same-day delivery</li>
                            <li style="margin-bottom: 12px; padding-left: 24px; position: relative;">✓ No preservatives or additives</li>
                            <li style="margin-bottom: 12px; padding-left: 24px; position: relative;">✓ Support local farmers</li>
                            <li style="margin-bottom: 12px; padding-left: 24px; position: relative;">✓ Sustainable farming practices</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="product-section">
            <h2>Our Commitment</h2>
            <div class="grid cards">
                <article class="card">
                    <h3>Freshness Guaranteed</h3>
                    <p>We guarantee that all our produce is harvested within 24 hours of delivery. If you're not completely satisfied with the freshness, we'll replace it free of charge.</p>
                </article>
                <article class="card">
                    <h3>Quality First</h3>
                    <p>Every item is inspected before packing to ensure it meets our high standards. We only work with certified organic farms and trusted local growers.</p>
                </article>
                <article class="card">
                    <h3>Sustainable Practices</h3>
                    <p>We're committed to environmentally friendly practices, from our packaging choices to our support of sustainable farming methods.</p>
                </article>
                <article class="card">
                    <h3>Community Support</h3>
                    <p>By choosing Fresh Harvest, you're supporting local farmers and contributing to the growth of sustainable agriculture in our community.</p>
                </article>
            </div>
        </section>

        <section class="product-section">
            <h2>Contact Us</h2>
            <div style="max-width: 600px; margin: 0 auto; text-align: center;">
                <p>Have questions about our products or services? We'd love to hear from you!</p>
                <div style="background: #f9fbfc; padding: 30px; border-radius: 16px; margin-top: 20px;">
                    <p><strong>Email:</strong> hello@freshharvest.local</p>
                    <p><strong>Phone:</strong> (555) 123-FRESH</p>
                    <p><strong>Hours:</strong> Monday - Saturday: 8AM - 8PM</p>
                    <p><strong>Delivery Area:</strong> Local area within 25 miles</p>
                </div>
            </div>
        </section>

        <section class="product-section" style="background: #f3f7f6; margin: 40px -20px; padding: 40px 20px;">
            <h2 style="text-align: center; margin-bottom: 20px;">Stay Connected</h2>
            <div style="max-width: 500px; margin: 0 auto; text-align: center;">
                <p>Subscribe to our newsletter for exclusive deals, seasonal updates, and healthy recipes delivered to your inbox.</p>
                <form method="POST" style="margin-top: 20px;">
                    <input type="email" name="newsletter_email" placeholder="Enter your email address" required style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 6px; font-size: 16px; margin-bottom: 15px;">
                    <button type="submit" name="subscribe_newsletter" style="background: #2a8f66; color: white; padding: 12px 30px; border: none; border-radius: 6px; font-size: 16px; font-weight: 600; cursor: pointer;">Subscribe Now</button>
                </form>
            </div>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest. All rights reserved.</div></footer>
</body>
</html>