<?php
require_once '../config/db.php';
session_start();

$cart = $_SESSION['cart'] ?? [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['quantities'] as $productId => $quantity) {
            $quantity = max(0, (int) $quantity);
            if ($quantity === 0) {
                unset($cart[$productId]);
            } else {
                $cart[$productId] = $quantity;
            }
        }
        $_SESSION['cart'] = $cart;
    }
    if (isset($_POST['clear'])) {
        unset($_SESSION['cart']);
        $cart = [];
    }
    header('Location: cart.php');
    exit;
}

$items = [];
$total = 0;
if ($cart) {
    $ids = implode(',', array_map('intval', array_keys($cart)));
    $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
    $products = $stmt->fetchAll();
    foreach ($products as $product) {
        $qty = $cart[$product['id']];
        $subtotal = $product['price'] * $qty;
        $items[] = ['product' => $product, 'quantity' => $qty, 'subtotal' => $subtotal];
        $total += $subtotal;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%232a8f66'/><text x='50' y='70' font-size='60' font-weight='bold' fill='white' text-anchor='middle'>F</text></svg>">
    <style>
        .product-image { display: block; width: 100%; height: auto; }
        .product-image.loading { opacity: 0.5; }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.width = '100%';
                fallback.style.aspectRatio = '1';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontWeight = '500';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('.product-image').forEach(img => {
                img.addEventListener('error', function() { handleImageError(this); });
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="product-section">
            <h2>Your Cart</h2>
            <?php if (empty($items)): ?>
                <p>Your cart is empty. <a href="menu.php">Shop now</a>.</p>
            <?php else: ?>
                <form method="post" class="cart-table">
                    <table>
                        <thead>
                            <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['product']['name']) ?></td>
                                <td>₹<?= number_format($item['product']['price'], 2) ?></td>
                                <td><input type="number" name="quantities[<?= $item['product']['id'] ?>]" value="<?= $item['quantity'] ?>" min="0"></td>
                                <td>₹<?= number_format($item['subtotal'], 2) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="cart-summary">
                        <strong>Total: ₹<?= number_format($total, 2) ?></strong>
                        <div>
                            <button type="submit" name="update">Update Cart</button>
                            <button type="submit" name="clear" class="danger">Clear Cart</button>
                            <a class="button" href="checkout.php">Checkout</a>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
