<?php
require_once '../config/db.php';
session_start();

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header('Location: menu.php');
    exit;
}

$message = '';
$coupon_discount = 0;
$coupon_code = $_SESSION['coupon_code'] ?? '';

// Handle coupon code
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_coupon'])) {
    $code = trim($_POST['coupon_code'] ?? '');
    if ($code) {
        $stmt = $pdo->prepare('SELECT * FROM coupons WHERE code = ? AND is_active = TRUE AND valid_from <= NOW() AND valid_until >= NOW()');
        $stmt->execute([$code]);
        $coupon = $stmt->fetch();
        
        if ($coupon) {
            if ($coupon['max_usage'] !== null && $coupon['usage_count'] >= $coupon['max_usage']) {
                $message = 'This coupon has reached its usage limit.';
            } else {
                // Calculate total to check minimum order amount
                $total = 0;
                $ids = implode(',', array_map('intval', array_keys($cart)));
                $products = $pdo->query("SELECT * FROM products WHERE id IN ($ids)")->fetchAll();
                foreach ($products as $product) {
                    $total += $product['price'] * $cart[$product['id']];
                }
                
                if ($total < $coupon['min_order_amount'])  {
                    $message = "Minimum order amount of ₹" . number_format($coupon['min_order_amount'], 2) . " required for this coupon.";
                } else {
                    $_SESSION['coupon_code'] = $code;
                    $_SESSION['coupon_id'] = $coupon['id'];
                    header('Location: checkout.php');
                    exit;
                }
            }
        } else {
            $message = 'Invalid or expired coupon code.';
        }
    }
}

// Handle remove coupon
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_coupon'])) {
    unset($_SESSION['coupon_code']);
    unset($_SESSION['coupon_id']);
    header('Location: checkout.php');
    exit;
}

// Calculate totals
$total = 0;
$ids = implode(',', array_map('intval', array_keys($cart)));
$products = $pdo->query("SELECT * FROM products WHERE id IN ($ids)")->fetchAll();

// Check stock availability
$stockErrors = [];
foreach ($products as $product) {
    $requestedQty = $cart[$product['id']];
    if ($requestedQty > $product['stock']) {
        $stockErrors[] = htmlspecialchars($product['name']) . " (requested: {$requestedQty}, available: {$product['stock']})";
    }
    $total += $product['price'] * $requestedQty;
}

// Apply coupon discount if applicable
if ($coupon_code && isset($_SESSION['coupon_id'])) {
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE id = ?');
    $stmt->execute([$_SESSION['coupon_id']]);
    $coupon = $stmt->fetch();
    if ($coupon && $coupon['discount_type'] === 'percentage') {
        $coupon_discount = ($total * $coupon['discount_value']) / 100;
    } else if ($coupon && $coupon['discount_type'] === 'flat') {
        $coupon_discount = min($coupon['discount_value'], $total);
    }
}

$final_total = $total - $coupon_discount;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name === '' || $email === '' || $address === '') {
        $message = 'Please complete all required fields.';
    } elseif (!empty($stockErrors)) {
        $message = 'Some items are out of stock or insufficient quantity available: ' . implode(', ', $stockErrors);
    } else {
        // Check if user is logged in
        if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] && isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            // Update user information for logged-in users
            $pdo->prepare('UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?')->execute([$name, $phone, $address, $userId]);
        } else {
            // Handle guest checkout
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            if ($user) {
                $userId = $user['id'];
                $pdo->prepare('UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?')->execute([$name, $phone, $address, $userId]);
            } else {
                $stmt = $pdo->prepare('INSERT INTO users (name, email, phone, address) VALUES (?, ?, ?, ?)');
                $stmt->execute([$name, $email, $phone, $address]);
                $userId = $pdo->lastInsertId();
            }
        }

        $stmt = $pdo->prepare('INSERT INTO orders (user_id, total_amount, status, created_at) VALUES (?, ?, ?, NOW())');
        $stmt->execute([$userId, $final_total, 'Pending']);
        $orderId = $pdo->lastInsertId();

        $itemStmt = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)');
        foreach ($products as $product) {
            $itemStmt->execute([$orderId, $product['id'], $cart[$product['id']], $product['price']]);
            // Reduce stock
            $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')->execute([$cart[$product['id']], $product['id']]);
        }

        // Apply coupon usage
        if ($coupon_code && isset($_SESSION['coupon_id'])) {
            $couponStmt = $pdo->prepare('INSERT INTO order_coupons (order_id, coupon_id, discount_amount) VALUES (?, ?, ?)');
            $couponStmt->execute([$orderId, $_SESSION['coupon_id'], $coupon_discount]);
            $pdo->prepare('UPDATE coupons SET usage_count = usage_count + 1 WHERE id = ?')->execute([$_SESSION['coupon_id']]);
        }

        unset($_SESSION['cart']);
        unset($_SESSION['coupon_code']);
        unset($_SESSION['coupon_id']);
        header('Location: thank-you.php?order=' . $orderId);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%232a8f66'/><text x='50' y='70' font-size='60' font-weight='bold' fill='white' text-anchor='middle'>F</text></svg>">
    <style>
        .product-image { display: block; width: 100%; height: auto; }
        .product-image.loading { opacity: 0.5; }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.width = '100%';
                fallback.style.aspectRatio = '1';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontWeight = '500';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('.product-image').forEach(img => {
                img.addEventListener('error', function() { handleImageError(this); });
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="product-section">
            <h2>Checkout</h2>
            <?php if ($message): ?><div class="alert error"><?= htmlspecialchars($message) ?></div><?php endif; ?>
            
            <!-- Coupon Code Section -->
            <div style="background: #f3f7f6; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #2a8f66;">Discount Code</h3>
                <?php if ($coupon_code): ?>
                    <div style="background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #4caf50;">
                        <p style="margin: 0 0 10px 0;"><strong style="color: #4caf50;">✓ Coupon Applied: <?= htmlspecialchars($coupon_code) ?></strong></p>
                        <p style="margin: 0; color: #666; font-size: 14px;">Discount: <strong style="color: #4caf50;">₹<?= number_format($coupon_discount, 2) ?></strong></p>
                        <form method="post" style="margin-top: 10px;">
                            <button type="submit" name="remove_coupon" value="1" class="reset-btn" style="background: #999; color: white; padding: 8px 15px; border: none; border-radius: 6px; cursor: pointer; font-size: 12px;">Remove Code</button>
                        </form>
                    </div>
                <?php else: ?>
                    <form method="post" style="display: flex; gap: 10px;">
                        <input type="text" name="coupon_code" placeholder="Enter coupon code" style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                        <button type="submit" name="apply_coupon" value="1" class="filter-btn" style="background: #2a8f66; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; white-space: nowrap;">Apply Code</button>
                    </form>
                    <p style="margin-top: 10px; font-size: 13px; color: #999;">Try: WELCOME10, FRESH50, ORGANIC15</p>
                <?php endif; ?>
            </div>

            <!-- Order Summary -->
            <div style="background: #f9f9f9; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #333;">Order Summary</h3>
                <table style="width: 100%; font-size: 14px;">
                    <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 10px 0;">Subtotal (<?= count($products) ?> items)</td>
                        <td style="text-align: right; padding: 10px 0;"><strong>₹<?= number_format($total, 2) ?></strong></td>
                    </tr>
                    <?php if ($coupon_discount > 0): ?>
                    <tr style="border-bottom: 1px solid #ddd; color: #4caf50;">
                        <td style="padding: 10px 0;">Discount (<?= htmlspecialchars($coupon_code) ?>)</td>
                        <td style="text-align: right; padding: 10px 0;"><strong>-₹<?= number_format($coupon_discount, 2) ?></strong></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td style="padding: 10px 0; font-size: 16px;"><strong>Total Amount</strong></td>
                        <td style="text-align: right; padding: 10px 0; font-size: 16px;"><strong style="color: #2a8f66;">₹<?= number_format($final_total, 2) ?></strong></td>
                    </tr>
                </table>
            </div>

            <!-- Checkout Form -->
            <form method="post" class="form-grid">
                <label>Name</label>
                <input type="text" name="name" value="<?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>" required>
                <label>Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>" required>
                <label>Phone</label>
                <input type="tel" name="phone">
                <label>Delivery address</label>
                <textarea name="address" rows="4" required></textarea>
                <?php if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']): ?>
                <div style="background: #e8f6ea; padding: 12px; border-radius: 8px; margin-bottom: 16px;">
                    <p style="margin: 0; color: #266b3c; font-size: 0.9rem;">
                        <strong>💡 Tip:</strong> <a href="login.php" style="color: #2a8f66;">Create an account</a> to save your information for future orders!
                    </p>
                </div>
                <?php endif; ?>
                <button type="submit" name="place_order" value="1">Place Order - ₹<?= number_format($final_total, 2) ?></button>
            </form>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
