<?php
require_once '../config/db.php';
session_start();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message_text = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message_text)) {
        $message = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address.';
    } else {
        $message = 'Thank you for your message! We will get back to you soon.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .contact-page { padding: 60px 0; background: #f9f9f9; }
        .contact-content { display: grid; grid-template-columns: 1fr 1fr; gap: 50px; margin-top: 40px; }
        .contact-info h2 { color: #2a8f66; margin-bottom: 20px; }
        .contact-info p { font-size: 16px; line-height: 1.6; margin-bottom: 30px; }
        .contact-details { display: flex; flex-direction: column; gap: 20px; }
        .contact-item { display: flex; align-items: flex-start; gap: 15px; }
        .contact-item i { color: #2a8f66; font-size: 20px; margin-top: 5px; }
        .contact-item strong { display: block; margin-bottom: 5px; color: #333; }
        .contact-form h2 { color: #2a8f66; margin-bottom: 20px; }
        .contact-form .form-group { margin-bottom: 20px; }
        .contact-form label { display: block; margin-bottom: 5px; font-weight: 600; color: #333; }
        .contact-form input, .contact-form textarea { width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 6px; font-size: 16px; transition: border-color 0.3s; }
        .contact-form input:focus, .contact-form textarea:focus { outline: none; border-color: #2a8f66; }
        .contact-form textarea { resize: vertical; min-height: 120px; }
        .btn-primary { background: #2a8f66; color: white; padding: 12px 30px; border: none; border-radius: 6px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.3s; }
        .btn-primary:hover { background: #1f6b52; }
        .alert { padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .alert.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        @media (max-width: 768px) { .contact-content { grid-template-columns: 1fr; gap: 30px; } }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="contact-page">
            <h1>Contact Us</h1>

            <?php if ($message): ?>
                <div class="alert <?= strpos($message, 'Thank you') !== false ? 'success' : 'error' ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <div class="contact-content">
                <div class="contact-info">
                    <h2>Get in Touch</h2>
                    <p>We'd love to hear from you! Send us a message and we'll respond as soon as possible.</p>

                    <div class="contact-details">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <div>
                                <strong>Address</strong><br>
                                123 Fresh Street<br>
                                Garden City, GC 12345
                            </div>
                        </div>

                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <div>
                                <strong>Phone</strong><br>
                                +1 (555) 123-4567
                            </div>
                        </div>

                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <div>
                                <strong>Email</strong><br>
                                info@freshharvest.com
                            </div>
                        </div>

                        <div class="contact-item">
                            <i class="fas fa-clock"></i>
                            <div>
                                <strong>Business Hours</strong><br>
                                Mon - Fri: 8:00 AM - 6:00 PM<br>
                                Sat: 9:00 AM - 4:00 PM<br>
                                Sun: Closed
                            </div>
                        </div>
                    </div>
                </div>

                <div class="contact-form">
                    <h2>Send us a Message</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" required>
                        </div>

                        <div class="form-group">
                            <label for="subject">Subject *</label>
                            <input type="text" id="subject" name="subject" required>
                        </div>

                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" name="message" rows="6" required></textarea>
                        </div>

                        <button type="submit" class="btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="container">
            <div>&copy; 2026 Fresh Harvest. All rights reserved.</div>
        </div>
    </footer>
</body>
</html>