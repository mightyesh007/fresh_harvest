<?php
require_once '../config/db.php';
session_start();
$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$featured = $pdo->query('SELECT * FROM products ORDER BY id DESC LIMIT 6')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <style>
        .card-image img { background: linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%); }
        .card-image img[src*='placeholder'], .card-image img.placeholder { visibility: hidden; }
        .hero { 
            background: linear-gradient(rgba(42, 143, 102, 0.4), rgba(42, 143, 102, 0.5)), 
            url('../assets/images/background.jpg'); 
            background-size: cover; 
            background-position: center; 
        }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.width = '100%';
                fallback.style.height = '100%';
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontSize = '0.9rem';
                fallback.innerHTML = 'Image Loading...';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('img').forEach(function(img) {
                if (!img.complete) {
                    img.addEventListener('error', function() { handleImageError(img); });
                }
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="hero">
            <h1>Fresh fruits and vegetables delivered daily.</h1>
            <p>Choose farm-fresh produce, add to cart, and checkout in minutes.</p>
            <a class="button" href="menu.php">Shop Now</a>
        </section>
        <section class="product-section">
            <h2>Top categories</h2>
            <div class="grid cards">
                <?php foreach ($categories as $category): ?>
                <article class="card">
                    <h3><?= htmlspecialchars($category['name']) ?></h3>
                </article>
                <?php endforeach; ?>
            </div>
        </section>
        <section class="product-section">
            <h2>Featured products</h2>
            <div class="grid cards">
                <?php foreach ($featured as $product): ?>
                <article class="card">
                    <div class="card-image"><img src="../<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>"></div>
                    <h3><?= htmlspecialchars($product['name']) ?></h3>
                    <p><?= htmlspecialchars($product['description']) ?></p>
                    <strong>₹<?= number_format($product['price'], 2) ?></strong>
                    <a class="button small" href="menu.php">Buy</a>
                </article>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="container">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 20px;">
                <div>
                    <h4 style="color: #2a8f66; margin-bottom: 10px;">Stay Updated</h4>
                    <p style="color: #666; margin-bottom: 15px;">Subscribe to our newsletter for fresh deals and seasonal offers.</p>
                    <form method="post" style="display: flex; gap: 10px; max-width: 400px;">
                        <input type="email" name="newsletter_email" placeholder="Enter your email" required style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                        <button type="submit" name="subscribe_newsletter" style="background: #2a8f66; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">Subscribe</button>
                    </form>
                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subscribe_newsletter'])) {
                        $email = trim($_POST['newsletter_email']);
                        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            try {
                                $stmt = $pdo->prepare('INSERT IGNORE INTO newsletter (email) VALUES (?)');
                                $stmt->execute([$email]);
                                echo '<p style="color: #4caf50; margin-top: 10px; font-size: 14px;">✓ Successfully subscribed!</p>';
                            } catch (Exception $e) {
                                echo '<p style="color: #f44336; margin-top: 10px; font-size: 14px;">Subscription failed. Please try again.</p>';
                            }
                        } else {
                            echo '<p style="color: #f44336; margin-top: 10px; font-size: 14px;">Please enter a valid email address.</p>';
                        }
                    }
                    ?>
                </div>
                <div>
                    <h4 style="color: #2a8f66; margin-bottom: 10px;">Quick Links</h4>
                    <ul style="list-style: none; padding: 0; color: #666;">
                        <li style="margin-bottom: 8px;"><a href="menu.php" style="color: #666; text-decoration: none;">Shop All Products</a></li>
                        <li style="margin-bottom: 8px;"><a href="about.php" style="color: #666; text-decoration: none;">About Us</a></li>
                        <li style="margin-bottom: 8px;"><a href="login.php" style="color: #666; text-decoration: none;">Customer Login</a></li>
                        <li style="margin-bottom: 8px;"><a href="../admin/" style="color: #666; text-decoration: none;">Admin Login</a></li>
                    </ul>
                </div>
            </div>
            <div>&copy; 2026 Fresh Harvest. All rights reserved.</div>
        </div>
    </footer>
</body>
</html>
