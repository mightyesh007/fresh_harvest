<?php
require_once '../config/db.php';
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$message = '';
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        // Login process
        $email = trim($_POST['login_email'] ?? '');
        $password = trim($_POST['login_password'] ?? '');

        if ($email === '' || $password === '') {
            $message = 'Please enter both email and password.';
        } else {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND is_registered = TRUE AND password IS NOT NULL LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                header('Location: index.php');
                exit;
            } else {
                $message = 'Invalid email or password.';
            }
        }
        $activeTab = 'login';
    } elseif (isset($_POST['register'])) {
        // Registration process
        $name = trim($_POST['register_name'] ?? '');
        $email = trim($_POST['register_email'] ?? '');
        $phone = trim($_POST['register_phone'] ?? '');
        $password = trim($_POST['register_password'] ?? '');
        $confirm_password = trim($_POST['register_confirm_password'] ?? '');

        if ($name === '' || $email === '' || $password === '') {
            $message = 'Please fill in all required fields.';
        } elseif ($password !== $confirm_password) {
            $message = 'Passwords do not match.';
        } elseif (strlen($password) < 6) {
            $message = 'Password must be at least 6 characters long.';
        } else {
            // Check if email already exists
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $message = 'An account with this email already exists.';
            } else {
                // Create new user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('INSERT INTO users (name, email, phone, password, is_registered, created_at) VALUES (?, ?, ?, ?, TRUE, NOW())');
                $stmt->execute([$name, $email, $phone, $hashed_password]);

                $message = 'Account created successfully! You can now log in.';
                $activeTab = 'login';
            }
        }
        $activeTab = 'register';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%232a8f66'/><text x='50' y='70' font-size='60' font-weight='bold' fill='white' text-anchor='middle'>F</text></svg>">
    <style>
        .product-image { display: block; width: 100%; height: auto; }
        .product-image.loading { opacity: 0.5; }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.width = '100%';
                fallback.style.aspectRatio = '1';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontWeight = '500';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('.product-image').forEach(img => {
                img.addEventListener('error', function() { handleImageError(this); });
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <a href="login.php">Login</a>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="auth-page">
            <div class="auth-container" style="width: min(500px, 100%);">
                <h1>Customer Account</h1>

                <!-- Tab Navigation -->
                <div style="display: flex; margin-bottom: 20px; border-bottom: 1px solid #e1e4ea;">
                    <a href="?tab=login" style="flex: 1; text-align: center; padding: 12px; text-decoration: none; color: <?= $activeTab === 'login' ? '#2a8f66' : '#666' ?>; border-bottom: 2px solid <?= $activeTab === 'login' ? '#2a8f66' : 'transparent' ?>; font-weight: <?= $activeTab === 'login' ? '600' : '400' ?>;">Login</a>
                    <a href="?tab=register" style="flex: 1; text-align: center; padding: 12px; text-decoration: none; color: <?= $activeTab === 'register' ? '#2a8f66' : '#666' ?>; border-bottom: 2px solid <?= $activeTab === 'register' ? '#2a8f66' : 'transparent' ?>; font-weight: <?= $activeTab === 'register' ? '600' : '400' ?>;">Register</a>
                </div>

                <?php if ($message): ?>
                    <div class="alert <?= strpos($message, 'successfully') !== false || strpos($message, 'coming soon') !== false ? 'success' : 'error' ?>">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Login Form -->
                <div id="login-tab" style="display: <?= $activeTab === 'login' ? 'block' : 'none' ?>;">
                    <form method="post" class="auth-form">
                        <label>Email Address</label>
                        <input type="email" name="login_email" required>
                        <label>Password</label>
                        <input type="password" name="login_password" required>
                        <button type="submit" name="login">Sign In</button>
                    </form>
                </div>

                <!-- Registration Form -->
                <div id="register-tab" style="display: <?= $activeTab === 'register' ? 'block' : 'none' ?>;">
                    <form method="post" class="auth-form">
                        <label>Full Name</label>
                        <input type="text" name="register_name" required>
                        <label>Email Address</label>
                        <input type="email" name="register_email" required>
                        <label>Phone Number (Optional)</label>
                        <input type="tel" name="register_phone">
                        <label>Password</label>
                        <input type="password" name="register_password" required minlength="6">
                        <label>Confirm Password</label>
                        <input type="password" name="register_confirm_password" required minlength="6">
                        <button type="submit" name="register">Create Account</button>
                    </form>
                </div>

                <div style="text-align: center; margin-top: 20px;">
                    <a href="index.php" class="button" style="background: #666;">Back to Home</a>
                </div>
            </div>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest. All rights reserved.</div></footer>
</body>
</html>