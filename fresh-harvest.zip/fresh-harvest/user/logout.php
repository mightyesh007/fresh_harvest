<?php
session_start();

// Clear user session data
unset($_SESSION['user_logged_in']);
unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);

// Redirect to home page
header('Location: index.php');
exit;
?>