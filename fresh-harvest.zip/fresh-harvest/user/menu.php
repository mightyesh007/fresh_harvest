<?php
require_once '../config/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = (int) $_POST['product_id'];
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = 0;
    }
    $_SESSION['cart'][$productId] += $quantity;
    header('Location: menu.php');
    exit;
}

// Handle wishlist toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_wishlist'])) {
    if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']) {
        header('Location: login.php');
        exit;
    }
    $productId = (int) $_POST['product_id'];
    $userId = $_SESSION['user_id'];
    
    $stmt = $pdo->prepare('SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$userId, $productId]);
    if ($stmt->fetch()) {
        $pdo->prepare('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?')->execute([$userId, $productId]);
    } else {
        $pdo->prepare('INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)')->execute([$userId, $productId]);
    }
    header('Location: menu.php?' . http_build_query($_GET));
    exit;
}

// Get all categories
$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();

// Get search, category filter, and sort parameters
$search = trim($_GET['search'] ?? '');
$category = (int) ($_GET['category'] ?? 0);
$sort = $_GET['sort'] ?? 'name';

// Build query
$query = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE 1=1';
$params = [];

if ($search) {
    $query .= ' AND (p.name LIKE ? OR p.description LIKE ?)';
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($category > 0) {
    $query .= ' AND p.category_id = ?';
    $params[] = $category;
}

// Apply sorting
$validSorts = ['name', 'price_asc', 'price_desc', 'newest'];
if (!in_array($sort, $validSorts)) $sort = 'name';

switch ($sort) {
    case 'price_asc': $query .= ' ORDER BY p.price ASC'; break;
    case 'price_desc': $query .= ' ORDER BY p.price DESC'; break;
    case 'newest': $query .= ' ORDER BY p.created_at DESC'; break;
    default: $query .= ' ORDER BY p.name ASC';
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Get user's wishlist if logged in
$wishlist = [];
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']) {
    $stmt = $pdo->prepare('SELECT product_id FROM wishlist WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $wishlist = array_column($stmt->fetchAll(), 'product_id');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <style>
        .shop-filters { background: #f3f7f6; padding: 20px; border-radius: 12px; margin-bottom: 30px; }
        .filter-group { margin-bottom: 15px; }
        .filter-group label { display: block; font-weight: 600; margin-bottom: 8px; color: #2a8f66; }
        .filter-group input, .filter-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        .filter-group input:focus, .filter-group select:focus { outline: none; border-color: #2a8f66; box-shadow: 0 0 0 3px rgba(42, 143, 102, 0.1); }
        .filter-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px; }
        .filter-btn { background: #2a8f66; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
        .filter-btn:hover { background: #1f6b4d; }
        .reset-btn { background: #999; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; margin-left: 10px; }
        .reset-btn:hover { background: #777; }
        .wishlist-btn { background: none; border: none; color: #d4604d; font-size: 18px; cursor: pointer; padding: 5px; }
        .wishlist-btn.active { color: #d4604d; }
        .wishlist-btn:hover { transform: scale(1.2); }
        .card-header { position: relative; }
        @media (max-width: 768px) { .filter-row { grid-template-columns: 1fr; } }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.width = '100%';
                fallback.style.height = '100%';
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontSize = '0.9rem';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('img').forEach(function(img) {
                if (!img.complete) {
                    img.addEventListener('error', function() { handleImageError(img); });
                }
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="product-section">
            <h2>Shop all products</h2>
            
            <!-- Filters & Search -->
            <div class="shop-filters">
                <form method="get" id="filterForm">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="search">Search Products</label>
                            <input type="text" id="search" name="search" placeholder="Search by name or description..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="filter-group">
                            <label for="category">Category</label>
                            <select id="category" name="category">
                                <option value="0">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $category === $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label for="sort">Sort By</label>
                            <select id="sort" name="sort">
                                <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Name (A-Z)</option>
                                <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price (Low to High)</option>
                                <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price (High to Low)</option>
                                <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest First</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="filter-btn">Apply Filters</button>
                    <a href="menu.php" class="reset-btn">Reset</a>
                </form>
            </div>

            <?php if (empty($products)): ?>
                <p style="text-align: center; color: #999; padding: 40px;">No products found. Try adjusting your filters.</p>
            <?php else: ?>
                <p style="margin-bottom: 20px; color: #666;">Found <?= count($products) ?> product<?= count($products) !== 1 ? 's' : '' ?></p>
                <div class="grid cards">
                    <?php foreach ($products as $product): ?>
                    <article class="card">
                        <div class="card-header" style="position: relative;">
                            <div class="card-image">
                                <img src="../<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                            </div>
                            <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                                <form method="post" style="position: absolute; top: 10px; right: 10px;">
                                    <input type="hidden" name="toggle_wishlist" value="1">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" class="wishlist-btn <?= in_array($product['id'], $wishlist) ? 'active' : '' ?>" title="Add to Wishlist">♥</button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <h3><a href="product.php?id=<?= $product['id'] ?>" style="text-decoration: none; color: inherit; cursor: pointer;"><?= htmlspecialchars($product['name']) ?></a></h3>
                        <p class="meta"><?= htmlspecialchars($product['category_name'] ?: 'Produce') ?></p>
                        <p><?= htmlspecialchars(substr($product['description'], 0, 100)) ?>...</p>
                        <div class="card-footer">
                            <strong>₹<?= number_format($product['price'], 2) ?></strong>
                            <form method="post" class="cart-form">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="number" name="quantity" value="1" min="1" class="qty-input">
                                <button type="submit">Add to Cart</button>
                            </form>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
