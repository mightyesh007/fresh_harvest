<?php
require_once '../config/db.php';
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$productId = (int) ($_GET['id'] ?? 0);

// Get product details
$stmt = $pdo->prepare('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?');
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: menu.php');
    exit;
}

// Get product reviews
$stmt = $pdo->prepare('SELECT r.*, u.name AS user_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC');
$stmt->execute([$productId]);
$reviews = $stmt->fetchAll();

// Calculate average rating
$averageRating = 0;
$ratingCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
if ($reviews) {
    $totalRating = 0;
    foreach ($reviews as $review) {
        $totalRating += $review['rating'];
        $ratingCounts[$review['rating']]++;
    }
    $averageRating = $totalRating / count($reviews);
}

// Handle review submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $rating = (int) ($_POST['rating'] ?? 0);
    $reviewText = trim($_POST['review_text'] ?? '');

    if ($rating >= 1 && $rating <= 5) {
        try {
            // Check if user already reviewed this product
            $stmt = $pdo->prepare('SELECT id FROM reviews WHERE user_id = ? AND product_id = ?');
            $stmt->execute([$userId, $productId]);
            $existingReview = $stmt->fetch();

            if ($existingReview) {
                $pdo->prepare('UPDATE reviews SET rating = ?, review_text = ?, created_at = NOW() WHERE user_id = ? AND product_id = ?')
                     ->execute([$rating, $reviewText, $userId, $productId]);
                $message = 'Review updated successfully!';
            } else {
                $pdo->prepare('INSERT INTO reviews (product_id, user_id, rating, review_text) VALUES (?, ?, ?, ?)')
                     ->execute([$productId, $userId, $rating, $reviewText]);
                $message = 'Review submitted successfully!';
            }
            header('Location: product.php?id=' . $productId);
            exit;
        } catch (Exception $e) {
            $message = 'Error submitting review: ' . $e->getMessage();
        }
    } else {
        $message = 'Please select a rating between 1-5 stars.';
    }
}

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = 0;
    }
    $_SESSION['cart'][$productId] += $quantity;
    header('Location: product.php?id=' . $productId);
    exit;
}

// Handle wishlist toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_wishlist'])) {
    $stmt = $pdo->prepare('SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$userId, $productId]);
    if ($stmt->fetch()) {
        $pdo->prepare('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?')->execute([$userId, $productId]);
    } else {
        $pdo->prepare('INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)')->execute([$userId, $productId]);
    }
    header('Location: product.php?id=' . $productId);
    exit;
}

// Check if product is in user's wishlist
$stmt = $pdo->prepare('SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?');
$stmt->execute([$userId, $productId]);
$isInWishlist = $stmt->fetch() ? true : false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <style>
        .product-detail { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
        .product-image { width: 100%; height: 400px; object-fit: cover; border-radius: 12px; }
        .product-info h1 { margin-bottom: 10px; color: #333; }
        .product-price { font-size: 28px; font-weight: bold; color: #2a8f66; margin-bottom: 20px; }
        .product-description { color: #666; line-height: 1.6; margin-bottom: 30px; }
        .action-buttons { display: flex; gap: 15px; margin-bottom: 30px; }
        .btn-primary { background: #2a8f66; color: white; padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-primary:hover { background: #1f6b4d; }
        .btn-secondary { background: #f3f7f6; color: #2a8f66; padding: 12px 24px; border: 2px solid #2a8f66; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-secondary:hover { background: #2a8f66; color: white; }
        .wishlist-btn { background: none; border: 2px solid #d4604d; color: #d4604d; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .wishlist-btn.active { background: #d4604d; color: white; }
        .rating-stars { display: flex; gap: 5px; margin-bottom: 10px; }
        .star { color: #ddd; font-size: 20px; }
        .star.filled { color: #ffc107; }
        .reviews-section { margin-top: 50px; }
        .review-card { background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 15px; }
        .review-header { display: flex; justify-content: space-between; margin-bottom: 10px; }
        .review-rating { font-weight: 600; }
        .review-text { color: #666; line-height: 1.5; }
        .write-review { background: #f3f7f6; padding: 30px; border-radius: 12px; margin-bottom: 30px; }
        .rating-input { display: flex; gap: 10px; margin-bottom: 15px; }
        .rating-input label { cursor: pointer; }
        .rating-input input[type="radio"] { display: none; }
        .rating-input .star { color: #ddd; font-size: 24px; }
        .rating-input input[type="radio"]:checked ~ .star { color: #ffc107; }
        .rating-input input[type="radio"]:checked ~ .star ~ .star { color: #ddd; }
        .quantity-input { width: 80px; padding: 8px; border: 1px solid #ddd; border-radius: 6px; text-align: center; }
        @media (max-width: 768px) { .product-detail { grid-template-columns: 1fr; } .action-buttons { flex-direction: column; } }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="product-detail">
            <div>
                <img src="../<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image">
            </div>
            <div class="product-info">
                <h1><?= htmlspecialchars($product['name']) ?></h1>
                <p class="meta" style="color: #2a8f66; margin-bottom: 15px;"><?= htmlspecialchars($product['category_name'] ?: 'Produce') ?></p>

                <?php if ($reviews): ?>
                <div class="rating-stars" style="margin-bottom: 15px;">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <span class="star <?= $i <= round($averageRating) ? 'filled' : '' ?>">★</span>
                    <?php endfor; ?>
                    <span style="margin-left: 10px; color: #666; font-size: 14px;">
                        <?= number_format($averageRating, 1) ?> stars (<?= count($reviews) ?> reviews)
                    </span>
                </div>
                <?php endif; ?>

                <div class="product-price">₹<?= number_format($product['price'], 2) ?></div>
                <div class="product-description"><?= htmlspecialchars($product['description']) ?></div>

                <div class="action-buttons">
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="add_to_cart" value="1">
                        <input type="number" name="quantity" value="1" min="1" class="quantity-input">
                        <button type="submit" class="btn-primary">Add to Cart</button>
                    </form>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="toggle_wishlist" value="1">
                        <button type="submit" class="wishlist-btn <?= $isInWishlist ? 'active' : '' ?>">
                            ♥ <?= $isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist' ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Write Review Section -->
        <div class="write-review">
            <h3>Write a Review</h3>
            <?php if ($message): ?>
                <div class="alert <?= strpos($message, 'Error') === false ? 'success' : 'error' ?>" style="margin-bottom: 20px;"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form method="post">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; font-weight: 600; margin-bottom: 8px;">Your Rating:</label>
                    <div class="rating-input">
                        <input type="radio" id="star5" name="rating" value="5"><label for="star5"><span class="star">★</span></label>
                        <input type="radio" id="star4" name="rating" value="4"><label for="star4"><span class="star">★</span></label>
                        <input type="radio" id="star3" name="rating" value="3"><label for="star3"><span class="star">★</span></label>
                        <input type="radio" id="star2" name="rating" value="2"><label for="star2"><span class="star">★</span></label>
                        <input type="radio" id="star1" name="rating" value="1"><label for="star1"><span class="star">★</span></label>
                    </div>
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="review_text" style="display: block; font-weight: 600; margin-bottom: 8px;">Your Review:</label>
                    <textarea id="review_text" name="review_text" rows="4" placeholder="Share your thoughts about this product..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; resize: vertical;"></textarea>
                </div>
                <button type="submit" name="submit_review" class="btn-primary">Submit Review</button>
            </form>
        </div>

        <!-- Reviews Section -->
        <div class="reviews-section">
            <h3>Customer Reviews (<?= count($reviews) ?>)</h3>

            <?php if ($reviews): ?>
                <?php foreach ($reviews as $review): ?>
                <div class="review-card">
                    <div class="review-header">
                        <strong><?= htmlspecialchars($review['user_name']) ?></strong>
                        <div class="review-rating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <span class="star <?= $i <= $review['rating'] ? 'filled' : '' ?>">★</span>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="review-text">
                        <?= htmlspecialchars($review['review_text']) ?: '<em>No review text provided</em>' ?>
                    </div>
                    <div style="font-size: 12px; color: #999; margin-top: 10px;">
                        <?= date('M d, Y', strtotime($review['created_at'])) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center; color: #999; padding: 40px;">No reviews yet. Be the first to review this product!</p>
            <?php endif; ?>
        </div>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
