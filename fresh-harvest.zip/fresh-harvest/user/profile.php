<?php
require_once '../config/db.php';
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Get user details
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Get user's orders
$stmt = $pdo->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([$userId]);
$orders = $stmt->fetchAll();

// Get user's wishlist
$stmt = $pdo->prepare('SELECT p.* FROM wishlist w JOIN products p ON w.product_id = p.id WHERE w.user_id = ? ORDER BY w.created_at DESC');
$stmt->execute([$userId]);
$wishlist = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <style>
        .profile-container { max-width: 1000px; margin: 40px auto; }
        .profile-header { background: linear-gradient(135deg, #2a8f66, #1f6b4d); color: white; padding: 30px; border-radius: 12px; margin-bottom: 30px; }
        .profile-header h1 { margin: 0 0 10px 0; }
        .profile-header p { margin: 5px 0; opacity: 0.9; }
        .tabs { display: flex; gap: 10px; margin-bottom: 30px; border-bottom: 2px solid #eee; }
        .tab-btn { background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; font-weight: 600; color: #666; border-bottom: 3px solid transparent; }
        .tab-btn.active { color: #2a8f66; border-bottom-color: #2a8f66; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .info-box { background: #f3f7f6; padding: 20px; border-radius: 8px; }
        .info-box label { display: block; font-weight: 600; color: #2a8f66; margin-bottom: 5px; }
        .info-box p { margin: 0; color: #333; }
        .order-card { background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 15px; border-left: 4px solid #2a8f66; }
        .order-card h3 { margin: 0 0 10px 0; color: #2a8f66; }
        .order-detail { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 15px; font-size: 14px; margin-bottom: 10px; }
        .order-detail-label { color: #999; }
        .status-pending { color: #ff9800; font-weight: 600; }
        .status-completed { color: #4caf50; font-weight: 600; }
        .wishlist-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 20px; }
        .wishlist-item { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 15px; text-align: center; }
        .wishlist-item img { width: 100%; height: 100px; object-fit: cover; border-radius: 6px; margin-bottom: 10px; }
        .wishlist-item h4 { margin: 10px 0 5px 0; font-size: 14px; }
        .wishlist-item .price { font-weight: 600; color: #2a8f66; margin-bottom: 10px; }
        .btn-primary { background: #2a8f66; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 12px; }
        .btn-primary:hover { background: #1f6b4d; }
        .empty-msg { text-align: center; color: #999; padding: 40px; }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($user['name']) ?>!</span>
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="profile-container">
            <div class="profile-header">
                <h1><?= htmlspecialchars($user['name']) ?></h1>
                <p>Email: <?= htmlspecialchars($user['email']) ?></p>
                <?php if ($user['phone']): ?><p>Phone: <?= htmlspecialchars($user['phone']) ?></p><?php endif; ?>
                <p>Member since <?= date('F d, Y', strtotime($user['created_at'])) ?></p>
            </div>

            <div class="tabs">
                <button class="tab-btn active" onclick="switchTab(event, 'info')">Account Info</button>
                <button class="tab-btn" onclick="switchTab(event, 'orders')">Order History</button>
                <button class="tab-btn" onclick="switchTab(event, 'wishlist')">Wishlist (<?= count($wishlist) ?>)</button>
            </div>

            <!-- Account Info Section -->
            <div id="info" class="tab-content active">
                <div class="info-grid">
                    <div class="info-box">
                        <label>Full Name</label>
                        <p><?= htmlspecialchars($user['name']) ?></p>
                    </div>
                    <div class="info-box">
                        <label>Email Address</label>
                        <p><?= htmlspecialchars($user['email']) ?></p>
                    </div>
                    <div class="info-box">
                        <label>Phone</label>
                        <p><?= htmlspecialchars($user['phone'] ?: 'Not provided') ?></p>
                    </div>
                    <div class="info-box">
                        <label>Delivery Address</label>
                        <p style="font-size: 14px;"><?= htmlspecialchars($user['address'] ?: 'Not provided') ?></p>
                    </div>
                </div>
            </div>

            <!-- Order History Section -->
            <div id="orders" class="tab-content">
                <?php if (empty($orders)): ?>
                    <div class="empty-msg">
                        <p>You haven't placed any orders yet.</p>
                        <a href="menu.php" class="btn-primary">Start Shopping</a>
                    </div>
                <?php else: ?>
                    <p style="margin-bottom: 20px; color: #666;">Total orders: <strong><?= count($orders) ?></strong></p>
                    <?php foreach ($orders as $order): ?>
                        <?php 
                            $stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
                            $stmt->execute([$order['id']]);
                            $items = $stmt->fetchAll();
                        ?>
                        <div class="order-card">
                            <h3>Order #<?= $order['id'] ?></h3>
                            <div class="order-detail">
                                <div>
                                    <div class="order-detail-label">Date</div>
                                    <div><?= date('M d, Y', strtotime($order['created_at'])) ?></div>
                                </div>
                                <div>
                                    <div class="order-detail-label">Total Amount</div>
                                    <div><strong>₹<?= number_format($order['total_amount'], 2) ?></strong></div>
                                </div>
                                <div>
                                    <div class="order-detail-label">Items</div>
                                    <div><?= count($items) ?> item<?= count($items) !== 1 ? 's' : '' ?></div>
                                </div>
                                <div>
                                    <div class="order-detail-label">Status</div>
                                    <div class="status-<?= strtolower($order['status']) ?>"><?= htmlspecialchars($order['status']) ?></div>
                                </div>
                            </div>
                            <details style="margin-top: 10px; font-size: 14px;">
                                <summary style="cursor: pointer; color: #2a8f66; font-weight: 600;">View items</summary>
                                <ul style="margin-top: 10px; padding-left: 20px;">
                                    <?php foreach ($items as $item): ?>
                                        <?php 
                                            $stmt = $pdo->prepare('SELECT name FROM products WHERE id = ?');
                                            $stmt->execute([$item['product_id']]);
                                            $product = $stmt->fetch();
                                        ?>
                                        <li><?= htmlspecialchars($product['name']) ?> × <?= $item['quantity'] ?> - ₹<?= number_format($item['price'] * $item['quantity'], 2) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </details>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Wishlist Section -->
            <div id="wishlist" class="tab-content">
                <?php if (empty($wishlist)): ?>
                    <div class="empty-msg">
                        <p>Your wishlist is empty. Add items from the shop to save them for later!</p>
                        <a href="menu.php" class="btn-primary">Browse Shop</a>
                    </div>
                <?php else: ?>
                    <p style="margin-bottom: 20px; color: #666;">You have <?= count($wishlist) ?> item<?= count($wishlist) !== 1 ? 's' : '' ?> in your wishlist</p>
                    <div class="wishlist-grid">
                        <?php foreach ($wishlist as $product): ?>
                            <div class="wishlist-item">
                                <img src="../<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                                <h4><?= htmlspecialchars(substr($product['name'], 0, 20)) ?></h4>
                                <div class="price">₹<?= number_format($product['price'], 2) ?></div>
                                <form method="post" action="menu.php" style="margin-bottom: 5px;">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" class="btn-primary">Add to Cart</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
    <script>
        function switchTab(event, tabName) {
            event.preventDefault();
            // Hide all tab content
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(c => c.classList.remove('active'));
            // Deactivate all buttons
            const buttons = document.querySelectorAll('.tab-btn');
            buttons.forEach(b => b.classList.remove('active'));
            // Show selected tab and activate button
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
</body>
</html>
