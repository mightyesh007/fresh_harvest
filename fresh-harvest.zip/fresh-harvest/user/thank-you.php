<?php
session_start();
$orderId = isset($_GET['order']) ? (int) $_GET['order'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%232a8f66'/><text x='50' y='70' font-size='60' font-weight='bold' fill='white' text-anchor='middle'>F</text></svg>">
    <style>
        .product-image { display: block; width: 100%; height: auto; }
        .product-image.loading { opacity: 0.5; }
    </style>
    <script>
        function handleImageError(img) {
            if (!img.hasAttribute('data-error-handled')) {
                img.setAttribute('data-error-handled', 'true');
                img.style.display = 'none';
                let fallback = document.createElement('div');
                fallback.style.background = 'linear-gradient(135deg, #e8e8e8 0%, #f0f0f0 100%)';
                fallback.style.width = '100%';
                fallback.style.aspectRatio = '1';
                fallback.style.display = 'flex';
                fallback.style.alignItems = 'center';
                fallback.style.justifyContent = 'center';
                fallback.style.color = '#999';
                fallback.style.fontWeight = '500';
                fallback.innerHTML = 'Image';
                img.parentNode.insertBefore(fallback, img);
            }
        }
        window.addEventListener('load', function() {
            document.querySelectorAll('.product-image').forEach(img => {
                img.addEventListener('error', function() { handleImageError(this); });
            });
        });
    </script>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']): ?>
                    <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="product-section success-page">
            <h2>Thank you for your order!</h2>
            <?php if ($orderId): ?>
                <p>Your order number is <strong>#<?= $orderId ?></strong>. We will contact you once your produce is ready for delivery.</p>
            <?php else: ?>
                <p>Your order has been received. We will be in touch shortly.</p>
            <?php endif; ?>
            <a class="button" href="index.php">Return Home</a>
        </section>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
