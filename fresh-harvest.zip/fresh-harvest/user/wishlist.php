<?php
require_once '../config/db.php';
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Get user's wishlist with products
$stmt = $pdo->prepare('SELECT p.* FROM wishlist w JOIN products p ON w.product_id = p.id WHERE w.user_id = ? ORDER BY w.created_at DESC');
$stmt->execute([$userId]);
$wishlist = $stmt->fetchAll();

// Handle adding product to cart from wishlist
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = (int) $_POST['product_id'];
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = 0;
    }
    $_SESSION['cart'][$productId] += $quantity;
    header('Location: wishlist.php');
    exit;
}

// Handle removing from wishlist
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_wishlist'])) {
    $productId = (int) $_POST['product_id'];
    $pdo->prepare('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?')->execute([$userId, $productId]);
    header('Location: wishlist.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist | Fresh Harvest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%232a8f66' width='100' height='100'/><text x='50' y='50' font-size='60' fill='white' text-anchor='middle' dominant-baseline='central'>F</text></svg>">
    <style>
        .wishlist-container { max-width: 1200px; margin: 40px auto; }
        .wishlist-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .wishlist-table th { background: #f3f7f6; padding: 15px; text-align: left; font-weight: 600; color: #2a8f66; }
        .wishlist-table td { padding: 15px; border-bottom: 1px solid #eee; }
        .wishlist-item-img { width: 80px; height: 80px; object-fit: cover; border-radius: 6px; }
        .wishlist-name { font-weight: 600; color: #333; }
        .wishlist-price { color: #2a8f66; font-weight: 600; }
        .btn-add-cart { background: #2a8f66; color: white; padding: 8px 15px; border: none; border-radius: 6px; cursor: pointer; }
        .btn-add-cart:hover { background: #1f6b4d; }
        .btn-remove { background: #d4604d; color: white; padding: 8px 15px; border: none; border-radius: 6px; cursor: pointer; font-size: 12px; }
        .btn-remove:hover { background: #c0433a; }
        .empty-wishlist { text-align: center; padding: 80px 20px; }
        .empty-wishlist h2 { color: #999; margin-bottom: 20px; }
        .btn-continue { background: #2a8f66; color: white; padding: 12px 30px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; }
        .btn-continue:hover { background: #1f6b4d; }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <div class="brand">Fresh Harvest</div>
            <nav class="top-nav">
                <a href="index.php">Home</a>
                <a href="menu.php">Shop</a>
                <a href="cart.php">Cart</a>
                <a href="about.php">About</a>
                <span style="color: #666; margin-left: 18px;">Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>!</span>
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
                <a href="../admin/">Admin Login</a>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="wishlist-container">
            <h2 style="margin-bottom: 30px;">My Wishlist</h2>
            
            <?php if (empty($wishlist)): ?>
                <div class="empty-wishlist">
                    <h2>Your wishlist is empty</h2>
                    <p style="color: #999; margin-bottom: 30px;">Add items from the shop to save them for later.</p>
                    <a href="menu.php" class="btn-continue">Continue Shopping</a>
                </div>
            <?php else: ?>
                <p style="margin-bottom: 20px; color: #666;">You have <?= count($wishlist) ?> item<?= count($wishlist) !== 1 ? 's' : '' ?> in your wishlist</p>
                <table class="wishlist-table">
                    <thead>
                        <tr>
                            <th width="80">Image</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th width="150">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($wishlist as $product): ?>
                        <tr>
                            <td><img src="../<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="wishlist-item-img"></td>
                            <td>
                                <div class="wishlist-name"><?= htmlspecialchars($product['name']) ?></div>
                                <div style="font-size: 13px; color: #999; margin-top: 5px;"><?= htmlspecialchars(substr($product['description'], 0, 60)) ?>...</div>
                            </td>
                            <td><span class="wishlist-price">₹<?= number_format($product['price'], 2) ?></span></td>
                            <td>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" class="btn-add-cart">Add to Cart</button>
                                </form>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="remove_wishlist" value="1">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" class="btn-remove">Remove</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </main>
    <footer class="site-footer"><div class="container">&copy; 2026 Fresh Harvest</div></footer>
</body>
</html>
